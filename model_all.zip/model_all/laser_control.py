import time, os, gc, sys
from media.sensor import *
from media.display import *
from media.media import *

# ================ 系统配置参数 ================
# 显示配置
DISPLAY_MODE = "LCD"  # 使用LCD屏幕显示
DISPLAY_WIDTH = 800   # LCD屏幕宽度(像素)
DISPLAY_HEIGHT = 480  # LCD屏幕高度(像素)

# 检测配置
DETECT_WIDTH = ALIGN_UP(320, 16)  # 检测区域宽度(16字节对齐)
DETECT_HEIGHT = 240               # 检测区域高度
BLACK_GRAY_THRESHOLD = 100        # 黑色边框的灰度阈值(0-255)黑色灰度阈值（越小越黑）

# ================ 全局变量 ================
sensor = None      # 传感器对象
img_count = 0      # 图像计数
img_okcount = 0    # 成功检测计数

def camera_init():
    """初始化摄像头和显示系统"""
    global sensor
    try:
        print("Initializing camera...")

        # 1. 初始化传感器
        sensor = Sensor(width=DETECT_WIDTH, height=DETECT_HEIGHT)
        sensor.reset()  # 重置传感器

        # 2. 配置传感器输出参数
        sensor.set_framesize(width=DETECT_WIDTH, height=DETECT_HEIGHT)
        sensor.set_pixformat(Sensor.RGB565)  # 使用RGB565色彩格式

        # 3. 初始化LCD显示 (K230开发板使用ST7701驱动芯片)
        Display.init(Display.ST7701,
                   width=DISPLAY_WIDTH,
                   height=DISPLAY_HEIGHT,
                   fps=30)  # 30帧/秒

        # 4. 初始化媒体管理器
        MediaManager.init()

        # 5. 启动传感器
        sensor.run()
        print("Camera initialization completed")

    except Exception as e:
        print(f"Camera init failed: {e}")
        raise

def camera_deinit():
    """释放摄像头和显示资源"""
    global sensor
    try:
        if sensor:
            sensor.stop()  # 停止传感器
        Display.deinit()   # 关闭显示
        os.exitpoint(os.EXITPOINT_ENABLE_SLEEP)
        time.sleep_ms(100)  # 短暂延时确保资源释放
        MediaManager.deinit()  # 释放媒体资源
    except Exception as e:
        print(f"Camera deinit error: {e}")

def detect_outer_rectangle(img):
    """
    检测图像中的外接矩形
    参数: img - 输入的图像对象
    返回: 布尔值表示是否检测到有效矩形
    """
    global img_okcount

    # 获取图像尺寸和中心点
    img_width = img.width()
    img_height = img.height()
    img_centerx = img_width // 2
    img_centery = img_height // 2

    # 1. 在图像中心绘制参考十字线
    img.draw_cross(img_centerx, img_centery,
                  color=(255, 255, 0),  # 黄色十字线
                  size=10,
                  thickness=2)

    # 2. 转换为灰度图像进行处理
    gray = img.to_grayscale()

    # 3. 查找图像中的矩形 (阈值2000控制检测灵敏度)
    counts = gray.find_rects(threshold=2000)
    max_area = 0
    best_rect = None

    # 4. 筛选最佳矩形
    for r in counts:
        x, y, w, h = r.rect()[0], r.rect()[1], r.rect()[2], r.rect()[3]
        area = w * h  # 计算矩形面积
        aspect_ratio = float(w) / h  # 计算宽高比

        # 筛选条件：宽高比1.2-1.6且面积最大,宽高比 1.2//1.6
        if 1.1 < aspect_ratio < 1.7 and area > max_area:
            max_area = area
            best_rect = r

    # 5. 如果找到最佳矩形
    if best_rect is not None:
        x1, y1 = best_rect.rect()[0], best_rect.rect()[1]
        x2, y2 = x1 + best_rect.rect()[2], y1 + best_rect.rect()[3]
        center_x = (x1 + x2) // 2
        center_y = (y1 + y2) // 2

        # 检查中心点是否在有效范围内
        if 10 < center_x < img_width and 10 < center_y < img_height:
            # 计算中心区域和边框的灰度值
            x = gray.get_statistics(roi=(center_x, center_y, 4, 4)).mean()
            border_roi1 = (x1, y1, best_rect.rect()[2], 5)
            avg_gray = gray.get_statistics(roi=border_roi1).mean()

            print(f"Center gray: {x}, Border gray: {avg_gray}")

            # 判断条件：边框足够黑(avg_gray < 阈值)且中心足够亮(x > 110)#中心灰度阈值 （80-150）
            if avg_gray < BLACK_GRAY_THRESHOLD and x > 110:
                img_okcount += 1

                # 6. 绘制检测结果可视化
                # 绘制红色矩形框
                img.draw_rectangle(best_rect.rect(),
                                  color=(255, 0, 0),  # 红色
                                  thickness=2)
                # 绘制矩形中心红点
                img.draw_circle(center_x, center_y,
                               5, color=(255, 0, 0), fill=True)
                # 绘制中心连线
                img.draw_line(center_x, center_y, img_centerx, img_centery,
                             color=(0, 255, 0),  # 绿色连线
                             thickness=2)
                # 绘制图像中心蓝点
                img.draw_circle(img_centerx, img_centery,
                               5, color=(0, 0, 255), fill=True)

                # 7. 显示检测信息文本
                img.draw_string(10, 10, f"Detected: {img_okcount}",
                              color=(255, 255, 255), scale=2)
                img.draw_string(10, 30, f"Center: ({center_x}, {center_y})",
                              color=(255, 255, 255), scale=1.5)
                img.draw_string(10, 50, f"Size: {best_rect.rect()[2]}x{best_rect.rect()[3]}",
                              color=(255, 255, 255), scale=1.5)

                return True

    # 8. 未检测到有效矩形的情况
    img.draw_string(10, 10, "No target detected",
                   color=(255, 0, 0),  # 红色文本
                   scale=2)
    return False

def capture_picture():
    """主捕获循环"""
    fps = time.clock()  # 帧率计时器
    frame_count = 0
    last_time = time.ticks_ms()

    while True:
        fps.tick()  # 更新帧率计时
        frame_count += 1
        current_time = time.ticks_ms()

        # 计算并显示帧率(每秒更新一次)
        if current_time - last_time >= 1000:
            fps_value = frame_count * 1000 / (current_time - last_time)
            print(f"FPS: {fps_value:.1f}")
            frame_count = 0
            last_time = current_time

        try:
            os.exitpoint()  # 检查退出点

            # 1. 捕获图像帧
            img = sensor.snapshot()

            # 2. 在图像右上角显示帧率
            img.draw_string(img.width() - 100, 10,
                           f"FPS: {fps.fps():.1f}",
                           color=(255, 255, 255),  # 白色文本
                           scale=1.5)

            # 3. 执行矩形检测
            detect_outer_rectangle(img)

            # 4. 显示到LCD屏幕
            Display.show_image(img)

            # 5. 释放资源
            img = None
            gc.collect()  # 垃圾回收

        except KeyboardInterrupt as e:
            print("User stop:", e)
            break
        except Exception as e:
            print(f"Capture error: {e}")
            break

def main():
    """主程序入口"""
    os.exitpoint(os.EXITPOINT_ENABLE)
    camera_is_init = False

    try:
        # 初始化摄像头
        camera_init()
        camera_is_init = True

        # 开始捕获循环
        print("Starting capture...")
        capture_picture()

    except Exception as e:
        print(f"Main error: {e}")
    finally:
        # 清理资源
        if camera_is_init:
            camera_deinit()
        print("Program ended")

if __name__ == "__main__":
    main()
