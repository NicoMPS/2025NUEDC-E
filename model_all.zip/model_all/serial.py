import time, os, gc, sys
import math
from media.sensor import *
from media.display import *
from media.media import *
from machine import UART, FPIOA, TOUCH

# ================ 系统配置 ================
DISPLAY_WIDTH = 800
DISPLAY_HEIGHT = 480
DETECT_WIDTH = ALIGN_UP(480, 16)
DETECT_HEIGHT = 360

# ================ A4纸物理尺寸(mm) ================
A4_WIDTH_MM = 297
A4_HEIGHT_MM = 210

# ================ 相机参数 ================
FOCAL_LENGTH_PX = 500
SENSOR_WIDTH_MM = 4.8
SENSOR_HEIGHT_MM = 3.6

# ================ 固定阈值 ================
THRESHOLD_VALUES = {
    "BLACK_GRAY_THRESHOLD": 149,  # 边框暗区阈值
    "CENTER_GRAY_THRESHOLD": 128, # 中心亮区阈值
    "RECT_DETECT_THRESHOLD": 2500, # 矩形检测灵敏度
    "BRIGHT_SPOT_THRESHOLD": 200   # 亮点检测阈值
}

# ================ 矩形宽高比限制 ================
MIN_ASPECT_RATIO = 1.1
MAX_ASPECT_RATIO = 1.8

# ================ UART配置 ================
UART_PORT = 2
UART_BAUDRATE = 115200
UART_TX_PIN = 11
UART_RX_PIN = 12
HEADER = 0x55
CHECKSUM = 0x77
FOOTER = 0x44

# ================ 全局变量 ================
sensor = None
uart = None
tp = None
running = True
img_okcount = 0
last_send_time = 0

def camera_init():
    global sensor, uart, tp
    try:
        print("初始化相机...")
        sensor = Sensor(width=DETECT_WIDTH, height=DETECT_HEIGHT)
        sensor.reset()
        sensor.set_framesize(width=DETECT_WIDTH, height=DETECT_HEIGHT)
        sensor.set_pixformat(Sensor.RGB565)

        # 初始化UART
        print("初始化UART2...")
        fpioa = FPIOA()
        fpioa.set_function(UART_TX_PIN, FPIOA.UART2_TXD)
        fpioa.set_function(UART_RX_PIN, FPIOA.UART2_RXD)

        uart = UART(UART_PORT, baudrate=UART_BAUDRATE)
        uart.init(
            baudrate=UART_BAUDRATE,
            bits=UART.EIGHTBITS,
            parity=UART.PARITY_NONE,
            stop=UART.STOPBITS_ONE
        )
        print(f"UART2初始化完成，波特率: {UART_BAUDRATE}")

        # 初始化显示
        Display.init(Display.ST7701, width=DISPLAY_WIDTH, height=DISPLAY_HEIGHT, fps=30)
        MediaManager.init()
        sensor.run()
        print("相机初始化完成")
    except Exception as e:
        print(f"相机初始化失败: {e}")
        raise

def camera_deinit():
    global sensor, uart, tp
    try:
        if sensor: sensor.stop()
        if uart: uart.deinit()
        Display.deinit()
        MediaManager.deinit()
    except Exception as e:
        print(f"相机释放错误: {e}")

def calculate_physical_position(rect, img_width, img_height):
    """
    计算A4纸上的物理坐标(mm)
    参数:
        rect: 检测到的矩形(x,y,w,h)
        img_width: 图像宽度(像素)
        img_height: 图像高度(像素)
    返回:
        (distance_mm, center_x_mm, center_y_mm, width_mm, height_mm)
    """
    x, y, w, h = rect
    pixel_width = w
    pixel_height = h

    # 计算实际距离
    distance_mm_width = (A4_WIDTH_MM * FOCAL_LENGTH_PX) / pixel_width
    distance_mm_height = (A4_HEIGHT_MM * FOCAL_LENGTH_PX) / pixel_height
    distance_mm = (distance_mm_width + distance_mm_height) / 2
    distance_mm = max(500, min(1600, distance_mm))

    # 计算物理坐标
    center_x_px = x + w/2 - img_width/2
    center_y_px = y + h/2 - img_height/2
    center_x_mm = (center_x_px * A4_WIDTH_MM) / pixel_width
    center_y_mm = (center_y_px * A4_HEIGHT_MM) / pixel_height

    # 计算实际尺寸
    width_mm = (w * A4_WIDTH_MM) / pixel_width
    height_mm = (h * A4_HEIGHT_MM) / pixel_height

    return distance_mm, center_x_mm, center_y_mm, width_mm, height_mm

def send_uart_data(rect_center_x_mm, rect_center_y_mm, delta_x_mm, delta_y_mm, bright_x_mm, bright_y_mm, distance_mm):
    """通过UART2发送数据，控制在50Hz"""
    global uart, last_send_time

    current_time = time.ticks_ms()
    if current_time - last_send_time < 20:
        return False

    if not uart:
        return False

    # 将mm值转换为0.1mm单位的整数
    rect_x_int = int(rect_center_x_mm * 10)
    rect_y_int = int(rect_center_y_mm * 10)
    delta_x_int = int(delta_x_mm * 10)
    delta_y_int = int(delta_y_mm * 10)
    bright_x_int = int(bight_x_mm * 10)
    bright_y_int = int(bright_y_mm * 10)
    distance_int = int(distance_mm)

    data = bytearray([
        HEADER,
        # 矩形中心X坐标(0.1mm)
        (rect_x_int >> 8) & 0xFF, rect_x_int & 0xFF,
        # 矩形中心Y坐标(0.1mm)
        (rect_y_int >> 8) & 0xFF, rect_y_int & 0xFF,
        # X偏差(0.1mm)
        (delta_x_int >> 8) & 0xFF, delta_x_int & 0xFF,
        # Y偏差(0.1mm)
        (delta_y_int >> 8) & 0xFF, delta_y_int & 0xFF,
        # 亮点X坐标(0.1mm)
        (bright_x_int >> 8) & 0xFF, bright_x_int & 0xFF,
        # 亮点Y坐标(0.1mm)
        (bright_y_int >> 8) & 0xFF, bright_y_int & 0xFF,
        # 距离(mm)
        (distance_int >> 8) & 0xFF, distance_int & 0xFF,
        CHECKSUM,
        FOOTER
    ])

    try:
        uart.write(data)
        last_send_time = current_time
        print(f"[UART] 发送: {[hex(b) for b in data]}")
        print(f"矩形中心: X={rect_center_x_mm:.1f}mm Y={rect_center_y_mm:.1f}mm")
        print(f"偏差: ΔX={delta_x_mm:.1f}mm ΔY={delta_y_mm:.1f}mm")
        print(f"亮点: X={bright_x_mm:.1f}mm Y={bright_y_mm:.1f}mm")
        print(f"距离: {distance_mm:.1f}mm")
        return True
    except Exception as e:
        print(f"UART发送失败: {e}")
        return False

def find_brightest_spot(gray_img, roi_rect=None):
    """
    在指定区域查找最亮点
    参数:
        gray_img: 灰度图像
        roi_rect: 感兴趣区域(x,y,w,h), None表示全图
    返回:
        (x, y, brightness) 最亮点的坐标和亮度
    """
    if roi_rect:
        x, y, w, h = roi_rect
        roi = gray_img.copy(roi=(x, y, w, h))
    else:
        roi = gray_img

    max_brightness = 0
    brightest_x, brightest_y = 0, 0

    for py in range(roi.height()):
        for px in range(roi.width()):
            brightness = roi.get_pixel(px, py)
            if brightness > max_brightness:
                max_brightness = brightness
                brightest_x = px
                brightest_y = py

    if roi_rect:
        brightest_x += roi_rect[0]
        brightest_y += roi_rect[1]

    return brightest_x, brightest_y, max_brightness

def detect_outer_rectangle(img):
    """使用固定阈值检测外矩形"""
    global img_okcount

    try:
        if img is None:
            print("错误: 输入图像为空")
            return False

        img_width = img.width()
        img_height = img.height()

        gray = img.to_grayscale()
        counts = gray.find_rects(threshold=THRESHOLD_VALUES["RECT_DETECT_THRESHOLD"])

        best_rect = None
        max_area = 0
        for r in counts:
            x, y, w, h = r.rect()
            area = w * h
            aspect_ratio = float(w) / h

            if MIN_ASPECT_RATIO < aspect_ratio < MAX_ASPECT_RATIO and area > max_area:
                max_area = area
                best_rect = r

        if best_rect:
            x1, y1 = best_rect.rect()[0], best_rect.rect()[1]
            x2, y2 = x1 + best_rect.rect()[2], y1 + best_rect.rect()[3]

            # 矩形中心坐标
            rect_center_x, rect_center_y = (x1 + x2) // 2, (y1 + y2) // 2
            # 屏幕中心坐标
            screen_center_x = img_width // 2
            screen_center_y = img_height // 2

            # 查找矩形区域内的最亮点
            brightest_x, brightest_y, max_brightness = find_brightest_spot(
                gray, roi_rect=(x1, y1, x2-x1, y2-y1))

            # 计算像素偏差
            delta_x_px = brightest_x - rect_center_x
            delta_y_px = brightest_y - rect_center_y

            border_gray = gray.get_statistics(roi=(x1, y1, best_rect.rect()[2], 5)).mean()
            center_gray = gray.get_statistics(roi=(rect_center_x, rect_center_y, 4, 4)).mean()

            # 始终绘制矩形和中心点
            img.draw_rectangle(best_rect.rect(), color=(255, 0, 0), thickness=2)
            img.draw_circle(rect_center_x, rect_center_y, 5, color=(255, 0, 0), fill=True)  # 矩形中心(红色)
            img.draw_circle(screen_center_x, screen_center_y, 5, color=(0, 0, 255), fill=True)  # 屏幕中心(蓝色)
            img.draw_line(screen_center_x, screen_center_y, rect_center_x, rect_center_y,
                        color=(0, 255, 0), thickness=2)  # 屏幕中心到矩形中心的连线(绿色)

            # 计算物理位置
            distance_mm, rect_center_x_mm, rect_center_y_mm, width_mm, height_mm = calculate_physical_position(
                best_rect.rect(), img_width, img_height)

            # 计算屏幕中心到矩形中心的偏差(mm)
            delta_x_px = rect_center_x - screen_center_x
            delta_y_px = rect_center_y - screen_center_y
            delta_x_mm = delta_x_px * A4_WIDTH_MM / width_mm
            delta_y_mm = delta_y_px * A4_HEIGHT_MM / height_mm

            # 如果检测到亮点
            if (border_gray < THRESHOLD_VALUES["BLACK_GRAY_THRESHOLD"] and
                center_gray > THRESHOLD_VALUES["CENTER_GRAY_THRESHOLD"] and
                max_brightness > THRESHOLD_VALUES["BRIGHT_SPOT_THRESHOLD"]):

                img_okcount += 1
                # 计算亮点物理坐标(mm)
                bright_x_mm = rect_center_x_mm + (delta_x_px * A4_WIDTH_MM / width_mm)
                bright_y_mm = rect_center_y_mm + (delta_y_px * A4_HEIGHT_MM / height_mm)

                # 绘制亮点和连线
                img.draw_circle(brightest_x, brightest_y, 5, color=(0, 255, 255), fill=True)  # 亮点(青色)
                img.draw_line(rect_center_x, rect_center_y, brightest_x, brightest_y,
                            color=(255, 0, 255), thickness=2)  # 矩形中心到亮点的连线(紫色)

                print(f"检测到激光点 - 亮度: {max_brightness}")
            else:
                # 无激光点时，使用矩形中心作为亮点坐标
                bright_x_mm = rect_center_x_mm
                bright_y_mm = rect_center_y_mm
                print("未检测到有效激光点")

            # 发送数据
            send_uart_data(rect_center_x_mm, rect_center_y_mm, delta_x_mm, delta_y_mm,
                         bright_x_mm, bright_y_mm, distance_mm)
            return True

        print("未检测到有效矩形")
        return False
    except Exception as e:
        print(f"检测错误: {e}")
        return False

def main_loop():
    fps = time.clock()
    while running:
        try:
            fps.tick()
            os.exitpoint()

            img = sensor.snapshot()

            # 检测矩形和亮点
            detect_outer_rectangle(img)

            # 显示图像
            Display.show_image(img)
            gc.collect()

        except KeyboardInterrupt:
            global running
            running = False
        except Exception as e:
            print(f"主循环错误: {e}")
            time.sleep(0.5)

def main():
    os.exitpoint(os.EXITPOINT_ENABLE)
    try:
        camera_init()
        main_loop()
    except Exception as e:
        print(f"主程序错误: {e}")
    finally:
        camera_deinit()
        print("程序结束")

if __name__ == "__main__":
    main()
