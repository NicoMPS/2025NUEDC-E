import time, os, gc, sys
import math
from media.sensor import *
from media.display import *
from media.media import *
from machine import UART, FPIOA, TOUCH

# ================ System Configuration ================
DISPLAY_WIDTH = 800
DISPLAY_HEIGHT = 480
DETECT_WIDTH = ALIGN_UP(800, 16)
DETECT_HEIGHT = 480

# ================ A4 Paper Physical Dimensions (mm) ================
A4_WIDTH_MM = 297
A4_HEIGHT_MM = 210

# ================ Camera Parameters ================
FOCAL_LENGTH_PX = 500
SENSOR_WIDTH_MM = 4.8
SENSOR_HEIGHT_MM = 3.6

# ================ Fixed Threshold Values ================
THRESHOLD_VALUES = {
    "BLACK_GRAY_THRESHOLD": 149,  # Border darkness threshold
    "CENTER_GRAY_THRESHOLD": 128, # Center brightness threshold
    "RECT_DETECT_THRESHOLD": 2500, # Rectangle detection sensitivity
    "BRIGHT_SPOT_THRESHOLD": 200   # Bright spot detection threshold
}

# ================ Rectangle Aspect Ratio Limits ================
MIN_ASPECT_RATIO = 1.1
MAX_ASPECT_RATIO = 1.8

# ================ UART Configuration ================
UART_PORT = 2
UART_BAUDRATE = 115200
UART_TX_PIN = 11
UART_RX_PIN = 12
HEADER = 0x55
CHECKSUM = 0x77
FOOTER = 0x44

# ================ Global Variables ================
sensor = None
uart = None
tp = None
running = True
img_okcount = 0
last_send_time = 0

def camera_init():
    global sensor, uart, tp
    try:
        print("Initializing camera...")
        sensor = Sensor(width=DETECT_WIDTH, height=DETECT_HEIGHT)
        sensor.reset()
        sensor.set_framesize(width=DETECT_WIDTH, height=DETECT_HEIGHT)
        sensor.set_pixformat(Sensor.RGB565)

        # Initialize UART
        print("Initializing UART2...")
        fpioa = FPIOA()
        fpioa.set_function(UART_TX_PIN, FPIOA.UART2_TXD)
        fpioa.set_function(UART_RX_PIN, FPIOA.UART2_RXD)

        uart = UART(UART_PORT, baudrate=UART_BAUDRATE)
        uart.init(
            baudrate=UART_BAUDRATE,
            bits=UART.EIGHTBITS,
            parity=UART.PARITY_NONE,
            stop=UART.STOPBITS_ONE
        )
        print(f"UART2 initialized at {UART_BAUDRATE} baud")

        # Initialize display
        Display.init(Display.ST7701, width=DISPLAY_WIDTH, height=DISPLAY_HEIGHT, fps=30)
        MediaManager.init()
        sensor.run()
        print("Camera initialization completed")
    except Exception as e:
        print(f"Camera init failed: {e}")
        raise

def camera_deinit():
    global sensor, uart, tp
    try:
        if sensor: sensor.stop()
        if uart: uart.deinit()
        Display.deinit()
        MediaManager.deinit()
    except Exception as e:
        print(f"Camera deinit error: {e}")

def calculate_physical_position(rect, img_width, img_height):
    """
    Calculate physical coordinates on A4 paper (mm)
    Parameters:
        rect: detected rectangle (x,y,w,h)
        img_width: image width (pixels)
        img_height: image height (pixels)
    Returns:
        (distance_mm, center_x_mm, center_y_mm, width_mm, height_mm)
    """
    x, y, w, h = rect
    pixel_width = w
    pixel_height = h

    # Calculate actual distance
    distance_mm_width = (A4_WIDTH_MM * FOCAL_LENGTH_PX) / pixel_width
    distance_mm_height = (A4_HEIGHT_MM * FOCAL_LENGTH_PX) / pixel_height
    distance_mm = (distance_mm_width + distance_mm_height) / 2
    distance_mm = max(500, min(1600, distance_mm))

    # Calculate physical coordinates
    center_x_px = x + w/2 - img_width/2
    center_y_px = y + h/2 - img_height/2
    center_x_mm = (center_x_px * A4_WIDTH_MM) / pixel_width
    center_y_mm = (center_y_px * A4_HEIGHT_MM) / pixel_height

    # Calculate actual dimensions
    width_mm = (w * A4_WIDTH_MM) / pixel_width
    height_mm = (h * A4_HEIGHT_MM) / pixel_height

    return distance_mm, center_x_mm, center_y_mm, width_mm, height_mm

def send_uart_data(rect_center_x_mm, rect_center_y_mm, delta_x_mm, delta_y_mm, bright_x_mm, bright_y_mm, distance_mm):
    """Send data via UART2, controlled at 50Hz"""
    global uart, last_send_time

    current_time = time.ticks_ms()
    if current_time - last_send_time < 20:
        return False

    if not uart:
        return False

    # Convert mm values to integers in 0.1mm units
    rect_x_int = int(rect_center_x_mm * 10)
    rect_y_int = int(rect_center_y_mm * 10)
    delta_x_int = int(delta_x_mm * 10)
    delta_y_int = int(delta_y_mm * 10)
    bright_x_int = int(bright_x_mm * 10)
    bright_y_int = int(bright_y_mm * 10)
    distance_int = int(distance_mm)

    data = bytearray([
        HEADER,
        # Rectangle center X coordinate (0.1mm)
        (rect_x_int >> 8) & 0xFF, rect_x_int & 0xFF,
        # Rectangle center Y coordinate (0.1mm)
        (rect_y_int >> 8) & 0xFF, rect_y_int & 0xFF,
        # Deviation X (0.1mm)
        (delta_x_int >> 8) & 0xFF, delta_x_int & 0xFF,
        # Deviation Y (0.1mm)
        (delta_y_int >> 8) & 0xFF, delta_y_int & 0xFF,
        # Bright spot X coordinate (0.1mm)
        (bright_x_int >> 8) & 0xFF, bright_x_int & 0xFF,
        # Bright spot Y coordinate (0.1mm)
        (bright_y_int >> 8) & 0xFF, bright_y_int & 0xFF,
        # Distance (mm)
        (distance_int >> 8) & 0xFF, distance_int & 0xFF,
        CHECKSUM,
        FOOTER
    ])

    try:
        uart.write(data)
        last_send_time = current_time
        print(f"[UART] Sent: {[hex(b) for b in data]}")
        print(f"Rectangle center: X={rect_center_x_mm:.1f}mm Y={rect_center_y_mm:.1f}mm")
        print(f"Deviation: ΔX={delta_x_mm:.1f}mm ΔY={delta_y_mm:.1f}mm")
        print(f"Bright spot: X={bright_x_mm:.1f}mm Y={bright_y_mm:.1f}mm")
        print(f"Distance: {distance_mm:.1f}mm")
        return True
    except Exception as e:
        print(f"UART send failed: {e}")
        return False

def find_brightest_spot(gray_img, roi_rect=None):
    """
    Find the brightest spot in the specified region
    Parameters:
        gray_img: grayscale image
        roi_rect: region of interest (x,y,w,h), None for full image
    Returns:
        (x, y, brightness) coordinates and brightness of the brightest spot
    """
    if roi_rect:
        x, y, w, h = roi_rect
        roi = gray_img.copy(roi=(x, y, w, h))
    else:
        roi = gray_img

    max_brightness = 0
    brightest_x, brightest_y = 0, 0

    for py in range(roi.height()):
        for px in range(roi.width()):
            brightness = roi.get_pixel(px, py)
            if brightness > max_brightness:
                max_brightness = brightness
                brightest_x = px
                brightest_y = py

    if roi_rect:
        brightest_x += roi_rect[0]
        brightest_y += roi_rect[1]

    return brightest_x, brightest_y, max_brightness

def detect_outer_rectangle(img):
    """Detect outer rectangle using fixed thresholds"""
    global img_okcount

    try:
        if img is None:
            print("Error: Input image is empty")
            return False

        img_width = img.width()
        img_height = img.height()

        gray = img.to_grayscale()
        counts = gray.find_rects(threshold=THRESHOLD_VALUES["RECT_DETECT_THRESHOLD"])

        best_rect = None
        max_area = 0
        for r in counts:
            x, y, w, h = r.rect()
            area = w * h
            aspect_ratio = float(w) / h

            if MIN_ASPECT_RATIO < aspect_ratio < MAX_ASPECT_RATIO and area > max_area:
                max_area = area
                best_rect = r

        if best_rect:
            x1, y1 = best_rect.rect()[0], best_rect.rect()[1]
            x2, y2 = x1 + best_rect.rect()[2], y1 + best_rect.rect()[3]

            # Rectangle center coordinates
            rect_center_x, rect_center_y = (x1 + x2) // 2, (y1 + y2) // 2

            # Find brightest spot in rectangle region
            brightest_x, brightest_y, max_brightness = find_brightest_spot(
                gray, roi_rect=(x1, y1, x2-x1, y2-y1))

            # Calculate pixel deviation from bright spot to rectangle center
            delta_x_px = brightest_x - rect_center_x
            delta_y_px = brightest_y - rect_center_y

            border_gray = gray.get_statistics(roi=(x1, y1, best_rect.rect()[2], 5)).mean()
            center_gray = gray.get_statistics(roi=(rect_center_x, rect_center_y, 4, 4)).mean()

            if (border_gray < THRESHOLD_VALUES["BLACK_GRAY_THRESHOLD"] and
                center_gray > THRESHOLD_VALUES["CENTER_GRAY_THRESHOLD"] and
                max_brightness > THRESHOLD_VALUES["BRIGHT_SPOT_THRESHOLD"]):

                img_okcount += 1
                distance_mm, rect_center_x_mm, rect_center_y_mm, width_mm, height_mm = calculate_physical_position(
                    best_rect.rect(), img_width, img_height)

                # Calculate bright spot physical coordinates (mm)
                bright_x_mm = rect_center_x_mm + (delta_x_px * A4_WIDTH_MM / width_mm)
                bright_y_mm = rect_center_y_mm + (delta_y_px * A4_HEIGHT_MM / height_mm)

                # Calculate physical deviation (mm)
                delta_x_mm = bright_x_mm - rect_center_x_mm
                delta_y_mm = bright_y_mm - rect_center_y_mm

                # Draw detection results - only the required elements
                img.draw_rectangle(best_rect.rect(), color=(255, 0, 0), thickness=2)
                img.draw_circle(rect_center_x, rect_center_y, 5, color=(255, 0, 0), fill=True)  # Rectangle center
                img.draw_circle(brightest_x, brightest_y, 5, color=(0, 255, 255), fill=True)     # Bright spot
                img.draw_line(brightest_x, brightest_y, rect_center_x, rect_center_y,
                            color=(255, 0, 255), thickness=2)  # Connection line

                # Send physical data in mm units
                send_uart_data(rect_center_x_mm, rect_center_y_mm, delta_x_mm, delta_y_mm, bright_x_mm, bright_y_mm, distance_mm)
                return True

        return False
    except Exception as e:
        print(f"Detection error: {e}")
        return False

def main_loop():
    fps = time.clock()
    while running:
        try:
            fps.tick()
            os.exitpoint()

            img = sensor.snapshot()
            img = img.mean_pool(2, 2)
            # Detect rectangle and bright spot
            detect_outer_rectangle(img)

            # Display image with only the required elements
            Display.show_image(img)
            gc.collect()

        except KeyboardInterrupt:
            global running
            running = False
        except Exception as e:
            print(f"Main loop error: {e}")
            time.sleep(0.5)

def main():
    os.exitpoint(os.EXITPOINT_ENABLE)
    try:
        camera_init()
        main_loop()
    except Exception as e:
        print(f"Main program error: {e}")
    finally:
        camera_deinit()
        print("Program ended")

if __name__ == "__main__":
    main()
