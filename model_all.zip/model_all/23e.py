import cv2 
import numpy as np

def detect_outer_rectangle(gray_img):
    blurred = cv2.GaussianBlur(gray_img, (5, 5), 0)
    edges = cv2.Canny(blurred, 50, 150) 
    contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

max_area = 0
best_rect= None
x,y,w,h = None, None, None, None
for contour in contours:
    area = cv2.contourArea(contour)
    if area < 2000:
        continue
    epsilon = 0.02 * cv2.arcLength(contour, True)
    approx = cv2.approxPolyDP(contour, epsilon, True)
    if len(approx) == 4:
        rect_x, rect_y, rect_w, rect_h = cv2.boundingRect(approx)
        aspect_ratio = float(rect_w) / rect_h
        #aspect_ratio = float(r.rect_h()[2]) / r.rect()[3] 宽高比
        if 0.5 < aspect_ratio < 2.0 and rect_w > max_area:
            max_area = rect_w
            best_rect = (rect_x, rect_y, rect_w, rect_h)
            x,y,w,h = rect_x, rect_y, rect_w, rect_h
    return best_rect, x, y, w, h

def process_frame(frame):
    display_frame = frame.copy()
    img_height, img_width = frame.shape[:2]
    img_center x,img_center_y = img_width // 2, img_height // 2
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    best_rect, x, y, w, h = detect_outer_rectangle(gray)
    status = "none"
    status_color = (0, 0, 255)  # Red by default

    if best_rect is not None:
        status_text = "have"
        status_color = (0, 255, 0)
        cv2.drawContours(display_img, [best_rect], -1, status_color, 2)
        center_x,center_y= (x + w // 2, y + h // 2)
        cv2.putText(display_img, f"({center_x},{center_y})", (center_x-40,center_y-10)
        cv2.FONT_HERSHEY_SIMPLEX, 0,6,(255,0,0),1)
        cv2.circle(display_img, (center_x, center_y), 6, (255, 0, 0), -1)
        offset_x = center_x - img_center_x
        offset_y = center_y - img_center_y
        cv2.line(display_img, (img_center_x, img_center_y), (center_x, center_y), (255, 0, 0), 2,cv2.LINE_AA)
        print(f"中点坐标: ({center_x}, {center_y}),偏移量: ({offset_x}, {offset_y})")
    cv2.putText(display_img, status_text, (10, 30), 
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, status_color, 2)
    return display_img
    