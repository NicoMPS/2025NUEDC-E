import time, os, gc, sys
import math
from media.sensor import *
from media.display import *
from media.media import *
from machine import UART, FPIOA, TOUCH
import nncase as nn
import ulab.numpy as np

# ================ 系统配置 ================
DISPLAY_WIDTH = 800
DISPLAY_HEIGHT = 480
DETECT_WIDTH = ALIGN_UP(480, 16)
DETECT_HEIGHT = 400

# ================ A4纸物理尺寸(mm) ================
A4_WIDTH_MM = 297
A4_HEIGHT_MM = 210

# ================ 摄像头参数 ================
FOCAL_LENGTH_PX = 500
SENSOR_WIDTH_MM = 4.8
SENSOR_HEIGHT_MM = 3.6

# ================ AI模型配置 ================
MODEL_PATH = "/sd/a4_laser_detector.kmodel"  # 替换为您的模型路径
INPUT_SHAPE = (224, 224, 3)  # 模型输入尺寸
CLASSES = ["background", "a4_corner", "laser_point"]  # 模型输出类别

# ================ 卡尔曼滤波配置 ================
KF_PROCESS_NOISE = 0.01
KF_MEASUREMENT_NOISE = 0.1
KF_DT = 0.1  # 时间间隔

# ================ 串口配置 ================
UART_PORT = 2
UART_BAUDRATE = 115200
UART_TX_PIN = 11
UART_RX_PIN = 12
HEADER = 0x55
CHECKSUM = 0x77
FOOTER = 0x44

# ================ 全局变量 ================
sensor = None
uart = None
interpreter = None
a4_kf = None
laser_kf = None
running = True
img_okcount = 0
last_send_time = 0
last_a4_center = None
last_laser_point = None

class KalmanFilter:
    """卡尔曼滤波器实现"""
    def __init__(self, dim_x, dim_z):
        self.dim_x = dim_x
        self.dim_z = dim_z

        # 状态向量
        self.x = None

        # 状态转移矩阵
        self.F = np.eye(dim_x)

        # 测量矩阵
        self.H = np.zeros((dim_z, dim_x))

        # 过程噪声协方差
        self.Q = np.eye(dim_x) * KF_PROCESS_NOISE

        # 测量噪声协方差
        self.R = np.eye(dim_z) * KF_MEASUREMENT_NOISE

        # 状态协方差
        self.P = np.eye(dim_x) * 100

        # 卡尔曼增益
        self.K = np.zeros((dim_x, dim_z))

    def predict(self):
        if self.x is None:
            return

        # 预测状态
        self.x = np.dot(self.F, self.x)

        # 预测协方差
        self.P = np.dot(np.dot(self.F, self.P), self.F.T) + self.Q

    def update(self, z):
        if self.x is None:
            # 第一次更新，初始化状态
            self.x = np.zeros(self.dim_x)
            self.x[:self.dim_z] = z
            return

        # 计算卡尔曼增益
        S = np.dot(np.dot(self.H, self.P), self.H.T) + self.R
        self.K = np.dot(np.dot(self.P, self.H.T), np.linalg.inv(S))

        # 更新状态估计
        y = z - np.dot(self.H, self.x)
        self.x = self.x + np.dot(self.K, y)

        # 更新协方差
        I = np.eye(self.dim_x)
        self.P = np.dot(I - np.dot(self.K, self.H), self.P)

def camera_init():
    """初始化摄像头、显示和AI模型"""
    global sensor, uart, interpreter, a4_kf, laser_kf

    try:
        print("Initializing K230 system...")

        # 初始化摄像头
        print("Initializing camera...")
        sensor = Sensor(width=DETECT_WIDTH, height=DETECT_HEIGHT)
        sensor.reset()
        sensor.set_framesize(width=DETECT_WIDTH, height=DETECT_HEIGHT)
        sensor.set_pixformat(Sensor.RGB565)

        # 初始化串口
        print("Initializing UART...")
        fpioa = FPIOA()
        fpioa.set_function(UART_TX_PIN, FPIOA.UART2_TXD)
        fpioa.set_function(UART_RX_PIN, FPIOA.UART2_RXD)

        uart = UART(UART_PORT, baudrate=UART_BAUDRATE)
        uart.init(
            baudrate=UART_BAUDRATE,
            bits=UART.EIGHTBITS,
            parity=UART.PARITY_NONE,
            stop=UART.STOPBITS_ONE
        )
        print(f"UART initialized at {UART_BAUDRATE} baud")

        # 加载AI模型
        print("Loading AI model...")
        with open(MODEL_PATH, 'rb') as f:
            model_data = f.read()

        # 创建解释器
        interpreter = nn.interpreter.Interpreter()
        interpreter.load_model(model_data)

        # 设置输入输出张量
        input_tensor = nn.runtime.TensorDesc(nn.runtime.DataType.UINT8,
                                            INPUT_SHAPE,
                                            nn.runtime.MemoryLayout.NHWC)
        interpreter.set_input_tensor(0, input_tensor)
        interpreter.set_output_tensor(0, nn.runtime.TensorDesc())
        print("AI model loaded successfully")

        # 初始化卡尔曼滤波器
        print("Initializing Kalman filters...")
        # 状态向量: [x, y, vx, vy]
        # 观测向量: [x, y]
        a4_kf = KalmanFilter(dim_x=4, dim_z=2)
        laser_kf = KalmanFilter(dim_x=4, dim_z=2)

        # 初始化卡尔曼滤波器参数
        # 状态转移矩阵 (假设匀速运动)
        a4_kf.F = np.array([[1, 0, KF_DT, 0],
                           [0, 1, 0, KF_DT],
                           [0, 0, 1, 0],
                           [0, 0, 0, 1]])

        laser_kf.F = np.array([[1, 0, KF_DT, 0],
                              [0, 1, 0, KF_DT],
                              [0, 0, 1, 0],
                              [0, 0, 0, 1]])

        # 测量矩阵
        a4_kf.H = np.array([[1, 0, 0, 0],
                           [0, 1, 0, 0]])

        laser_kf.H = np.array([[1, 0, 0, 0],
                             [0, 1, 0, 0]])

        # 初始化显示
        Display.init(Display.ST7701, width=DISPLAY_WIDTH, height=DISPLAY_HEIGHT, fps=30)
        MediaManager.init()
        sensor.run()
        print("System initialization completed")
    except Exception as e:
        print(f"Initialization failed: {e}")
        raise

def camera_deinit():
    """释放资源"""
    global sensor, uart
    try:
        if sensor: sensor.stop()
        if uart: uart.deinit()
        Display.deinit()
        MediaManager.deinit()
    except Exception as e:
        print(f"Deinit error: {e}")

def preprocess_image(img):
    """预处理图像以适应AI模型输入"""
    # 调整尺寸
    resized = img.resize(INPUT_SHAPE[1], INPUT_SHAPE[0])

    # 转换为RGB888格式
    rgb_img = resized.to_rgb888()

    # 转换为numpy数组
    np_img = np.array(rgb_img.data(), dtype=np.uint8).reshape(INPUT_SHAPE)

    # 归一化
    np_img = np_img / 255.0

    return np_img

def detect_objects(img):
    """使用AI模型检测目标"""
    global interpreter

    # 预处理图像
    input_data = preprocess_image(img)

    # 设置输入数据
    interpreter.set_input_tensor(0, nn.runtime.Tensor.from_numpy(input_data))

    # 运行推理
    interpreter.run()

    # 获取输出
    output_tensor = interpreter.get_output_tensor(0).to_numpy()

    # 解析输出 (假设输出格式为 [batch, num_boxes, 6] 其中6=4坐标+1置信度+1类别)
    detections = []
    for i in range(output_tensor.shape[1]):
        box = output_tensor[0, i]
        x1, y1, x2, y2, conf, cls_id = box
        if conf > 0.5:  # 置信度阈值
            detections.append({
                "class_id": int(cls_id),
                "class_name": CLASSES[int(cls_id)],
                "confidence": conf,
                "bbox": [x1, y1, x2, y2]
            })

    return detections

def calculate_physical_position(rect, img_width, img_height):
    """
    计算A4纸上的物理坐标(mm)
    参数:
        rect: 检测到的矩形 (x,y,w,h)
        img_width: 图像宽度(像素)
        img_height: 图像高度(像素)
    返回:
        (distance_mm, center_x_mm, center_y_mm, width_mm, height_mm)
    """
    x, y, w, h = rect
    pixel_width = w
    pixel_height = h

    # 计算实际距离
    distance_mm_width = (A4_WIDTH_MM * FOCAL_LENGTH_PX) / pixel_width
    distance_mm_height = (A4_HEIGHT_MM * FOCAL_LENGTH_PX) / pixel_height
    distance_mm = (distance_mm_width + distance_mm_height) / 2
    distance_mm = max(500, min(1600, distance_mm))

    # 计算物理坐标
    center_x_px = x + w/2 - img_width/2
    center_y_px = y + h/2 - img_height/2
    center_x_mm = (center_x_px * A4_WIDTH_MM) / pixel_width
    center_y_mm = (center_y_px * A4_HEIGHT_MM) / pixel_height

    return distance_mm, center_x_mm, center_y_mm, w, h

def send_uart_data(rect_center_x_mm, rect_center_y_mm, delta_x_mm, delta_y_mm, distance_mm):
    """通过串口发送数据"""
    global uart, last_send_time

    current_time = time.ticks_ms()
    if current_time - last_send_time < 20:  # 50Hz限制
        return False

    if not uart:
        return False

    # 将毫米值转换为0.1毫米单位的整数
    rect_x_int = int(rect_center_x_mm * 10)
    rect_y_int = int(rect_center_y_mm * 10)
    delta_x_int = int(delta_x_mm * 10)
    delta_y_int = int(delta_y_mm * 10)
    distance_int = int(distance_mm)

    data = bytearray([
        HEADER,
        # 矩形中心X坐标 (0.1mm)
        (rect_x_int >> 8) & 0xFF, rect_x_int & 0xFF,
        # 矩形中心Y坐标 (0.1mm)
        (rect_y_int >> 8) & 0xFF, rect_y_int & 0xFF,
        # 偏差X (0.1mm)
        (delta_x_int >> 8) & 0xFF, delta_x_int & 0xFF,
        # 偏差Y (0.1mm)
        (delta_y_int >> 8) & 0xFF, delta_y_int & 0xFF,
        # 距离 (mm)
        (distance_int >> 8) & 0xFF, distance_int & 0xFF,
        CHECKSUM,
        FOOTER
    ])

    try:
        uart.write(data)
        last_send_time = current_time
        print(f"[UART] Sent: {[hex(b) for b in data]}")
        print(f"矩形中心: X={rect_center_x_mm:.1f}mm Y={rect_center_y_mm:.1f}mm")
        print(f"偏差值: ΔX={delta_x_mm:.1f}mm ΔY={delta_y_mm:.1f}mm")
        print(f"距离: {distance_mm:.1f}mm")
        return True
    except Exception as e:
        print(f"UART send failed: {e}")
        return False

def process_frame(img):
    """处理单帧图像"""
    global img_okcount, last_a4_center, last_laser_point, a4_kf, laser_kf

    img_width = img.width()
    img_height = img.height()

    # AI检测目标
    detections = detect_objects(img)

    a4_bbox = None
    laser_bbox = None

    # 解析检测结果
    for det in detections:
        if det["class_name"] == "a4_corner":
            a4_bbox = det["bbox"]
        elif det["class_name"] == "laser_point":
            laser_bbox = det["bbox"]

    # 处理A4纸检测结果
    if a4_bbox:
        x, y, w, h = a4_bbox
        center_x = x + w/2
        center_y = y + h/2

        # 更新卡尔曼滤波器
        if a4_kf.x is None:
            a4_kf.x = np.array([center_x, center_y, 0, 0])
        else:
            a4_kf.predict()
            a4_kf.update(np.array([center_x, center_y]))

        last_a4_center = [a4_kf.x[0], a4_kf.x[1]]
    elif a4_kf.x is not None:
        # 如果没有检测到，使用卡尔曼滤波预测
        a4_kf.predict()
        last_a4_center = [a4_kf.x[0], a4_kf.x[1]]

    # 处理激光点检测结果
    if laser_bbox:
        x, y, w, h = laser_bbox
        center_x = x + w/2
        center_y = y + h/2

        # 更新卡尔曼滤波器
        if laser_kf.x is None:
            laser_kf.x = np.array([center_x, center_y, 0, 0])
        else:
            laser_kf.predict()
            laser_kf.update(np.array([center_x, center_y]))

        last_laser_point = [laser_kf.x[0], laser_kf.x[1]]
    elif laser_kf.x is not None:
        # 如果没有检测到，使用卡尔曼滤波预测
        laser_kf.predict()
        last_laser_point = [laser_kf.x[0], laser_kf.x[1]]

    # 计算物理位置和偏差
    if last_a4_center and last_laser_point:
        # 计算物理位置
        physical_data = calculate_physical_position(
            [last_a4_center[0]-50, last_a4_center[1]-50, 100, 100],
            img_width, img_height)

        distance_mm, center_x_mm, center_y_mm, w, h = physical_data

        # 计算偏差
        delta_x_px = last_laser_point[0] - last_a4_center[0]
        delta_y_px = last_laser_point[1] - last_a4_center[1]

        # 计算物理偏差
        delta_x_mm = (delta_x_px * A4_WIDTH_MM) / w
        delta_y_mm = (delta_y_px * A4_HEIGHT_MM) / h

        # 发送数据
        send_uart_data(center_x_mm, center_y_mm, delta_x_mm, delta_y_mm, distance_mm)

        # 绘制结果
        img.draw_rectangle(int(last_a4_center[0]-50), int(last_a4_center[1]-50),
                          100, 100, color=(255, 0, 0), thickness=2)
        img.draw_circle(int(last_a4_center[0]), int(last_a4_center[1]),
                        5, color=(255, 0, 0), fill=True)
        img.draw_circle(int(last_laser_point[0]), int(last_laser_point[1]),
                        5, color=(0, 255, 255), fill=True)
        img.draw_line(int(last_a4_center[0]), int(last_a4_center[1]),
                      int(last_laser_point[0]), int(last_laser_point[1]),
                      color=(255, 0, 255), thickness=2)

        img_okcount += 1
        return True

    return False

def main_loop():
    """主循环"""
    global running
    fps = time.clock()

    while running:
        try:
            fps.tick()
            os.exitpoint()

            # 捕获图像
            img = sensor.snapshot()

            # 处理图像
            if process_frame(img):
                img.draw_string(20, 20, "Detection success!", color=(0, 255, 0), scale=3)
            else:
                img.draw_string(20, 20, "No target detected", color=(255, 0, 0), scale=3)

            # 显示FPS
            img.draw_string(DISPLAY_WIDTH - 150, DISPLAY_HEIGHT - 40,
                          f"FPS: {fps.fps():.1f}", color=(255, 255, 255), scale=2)

            # 显示图像
            Display.show_image(img)
            gc.collect()

        except KeyboardInterrupt:
            running = False
        except Exception as e:
            print(f"Main loop error: {e}")
            time.sleep(0.5)

def main():
    """主函数"""
    os.exitpoint(os.EXITPOINT_ENABLE)
    try:
        camera_init()
        main_loop()
    except Exception as e:
        print(f"Main program error: {e}")
    finally:
        camera_deinit()
        print("Program ended")

if __name__ == "__main__":
    main()
