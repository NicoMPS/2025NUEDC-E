import time, os, gc, sys
import math
from media.sensor import *
from media.display import *
from media.media import *
from machine import UART, FPIOA, TOUCH

# ================ 系统配置 ================
DISPLAY_WIDTH = 800
DISPLAY_HEIGHT = 480
DETECT_WIDTH = ALIGN_UP(500, 16)
DETECT_HEIGHT = 320

# ================ A4纸物理尺寸(mm) ================
A4_WIDTH_MM = 210  # 短边
A4_HEIGHT_MM = 297  # 长边

# ================ 摄像头参数 ================
FOCAL_LENGTH_PX = 500
SENSOR_WIDTH_MM = 4.8
SENSOR_HEIGHT_MM = 3.6

# ================ 固定阈值配置 ================
THRESHOLD_VALUES = {
    "BLACK_GRAY_THRESHOLD": 149,  # 边框黑度阈值
    "CENTER_GRAY_THRESHOLD": 128, # 中心亮度阈值
    "RECT_DETECT_THRESHOLD": 2500, # 矩形检测灵敏度
    "BRIGHT_SPOT_THRESHOLD": 200   # 亮点检测阈值
}

# ================ 矩形宽高比限制 ================
MIN_ASPECT_RATIO = 1.1
MAX_ASPECT_RATIO = 1.8

# ================ 串口配置 ================
UART_PORT = 2
UART_BAUDRATE = 115200
UART_TX_PIN = 11
UART_RX_PIN = 12
HEADER = 0x55
CHECKSUM = 0x77
FOOTER = 0x44

# ================ 全局变量 ================
sensor = None
uart = None
running = True
last_send_time = 0
last_valid_rect = None
last_valid_center = None
img_okcount = 0

def camera_init():
    global sensor, uart
    try:
        print("正在初始化相机...")
        sensor = Sensor(width=DETECT_WIDTH, height=DETECT_HEIGHT)
        sensor.reset()
        sensor.set_framesize(width=DETECT_WIDTH, height=DETECT_HEIGHT)
        sensor.set_pixformat(Sensor.RGB565)

        # 初始化串口
        print("正在初始化UART2...")
        fpioa = FPIOA()
        fpioa.set_function(UART_TX_PIN, FPIOA.UART2_TXD)
        fpioa.set_function(UART_RX_PIN, FPIOA.UART2_RXD)

        uart = UART(UART_PORT, baudrate=UART_BAUDRATE)
        uart.init(
            baudrate=UART_BAUDRATE,
            bits=UART.EIGHTBITS,
            parity=UART.PARITY_NONE,
            stop=UART.STOPBITS_ONE
        )
        print(f"UART2初始化完成，波特率: {UART_BAUDRATE}")

        # 初始化显示
        Display.init(Display.SST7701, width=DISPLAY_WIDTH, height=DISPLAY_HEIGHT, fps=30)
        MediaManager.init()
        sensor.run()
        print("相机初始化完成")
    except Exception as e:
        print(f"相机初始化失败: {e}")
        raise

def camera_deinit():
    global sensor, uart
    try:
        if sensor: sensor.stop()
        if uart: uart.deinit()
        Display.deinit()
        MediaManager.deinit()
    except Exception as e:
        print(f"相机释放错误: {e}")

def calculate_distance(rect):
    """计算摄像头到矩形中心的距离(mm)"""
    _, _, w, h = rect
    distance_mm = (A4_HEIGHT_MM * FOCAL_LENGTH_PX) / h
    return max(500, min(1600, distance_mm))

def is_valid_position(rect_center, screen_center):
    """检查矩形中心位置是否合理"""
    if last_valid_center is None:
        return True

    # 计算与上次有效位置的偏移量
    dx = abs(rect_center[0] - last_valid_center[0])
    dy = abs(rect_center[1] - last_valid_center[1])

    # 如果偏移超过图像尺寸的30%，认为无效
    max_offset = min(DETECT_WIDTH, DETECT_HEIGHT) * 0.3
    return dx < max_offset and dy < max_offset

def send_uart_data(screen_center, target_pos, distance_mm):
    """通过UART2发送数据（16进制格式）"""
    global uart, last_send_time

    current_time = time.ticks_ms()
    if current_time - last_send_time < 20:  # 50Hz控制
        return False

    if not uart:
        return False

    sc_x = int(screen_center[0])
    sc_y = int(screen_center[1])
    tg_x = int(target_pos[0])
    tg_y = int(target_pos[1])
    dist = int(distance_mm)

    data = bytearray([
        HEADER,
        (sc_x >> 8) & 0xFF, sc_x & 0xFF,
        (sc_y >> 8) & 0xFF, sc_y & 0xFF,
        (tg_x >> 8) & 0xFF, tg_x & 0xFF,
        (tg_y >> 8) & 0xFF, tg_y & 0xFF,
        (dist >> 8) & 0xFF, dist & 0xFF,
        CHECKSUM,
        FOOTER
    ])

    try:
        uart.write(data)
        last_send_time = current_time
        print(f"[UART] 发送: {[hex(b) for b in data]}")
        print(f"屏幕中心: ({sc_x},{sc_y}) 目标点: ({tg_x},{tg_y}) 距离: {distance_mm:.1f}mm")
        return True
    except Exception as e:
        print(f"串口发送失败: {e}")
        return False

def find_brightest_spot(gray_img, roi_rect=None):
    """在指定区域查找最亮点"""
    if roi_rect:
        x, y, w, h = roi_rect
        roi = gray_img.copy(roi=(x, y, w, h))
    else:
        roi = gray_img

    max_brightness = 0
    brightest_x, brightest_y = 0, 0

    for py in range(roi.height()):
        for px in range(roi.width()):
            brightness = roi.get_pixel(px, py)
            if brightness > max_brightness:
                max_brightness = brightness
                brightest_x = px
                brightest_y = py

    if roi_rect:
        brightest_x += roi_rect[0]
        brightest_y += roi_rect[1]

    return brightest_x, brightest_y, max_brightness

def detect_outer_rectangle(img):
    """检测外接矩形并计算坐标"""
    global img_okcount, last_valid_rect, last_valid_center

    try:
        if img is None:
            print("错误: 输入图像为空")
            return False

        img_width = img.width()
        img_height = img.height()
        screen_center = (img_width // 2, img_height // 2)

        gray = img.to_grayscale()
        counts = gray.find_rects(threshold=THRESHOLD_VALUES["RECT_DETECT_THRESHOLD"])

        best_rect = None
        max_area = 0
        for r in counts:
            x, y, w, h = r.rect()
            area = w * h
            aspect_ratio = float(w) / h

            if MIN_ASPECT_RATIO < aspect_ratio < MAX_ASPECT_RATIO and area > max_area:
                max_area = area
                best_rect = r

        if best_rect:
            x1, y1 = best_rect.rect()[0], best_rect.rect()[1]
            x2, y2 = x1 + best_rect.rect()[2], y1 + best_rect.rect()[3]
            rect_center = ((x1 + x2) // 2, (y1 + y2) // 2)

            # 验证矩形有效性
            border_gray = gray.get_statistics(roi=(x1, y1, best_rect.rect()[2], 5)).mean()
            center_gray = gray.get_statistics(roi=(rect_center[0], rect_center[1], 4, 4)).mean()

            if (border_gray < THRESHOLD_VALUES["BLACK_GRAY_THRESHOLD"] and
                center_gray > THRESHOLD_VALUES["CENTER_GRAY_THRESHOLD"] and
                is_valid_position(rect_center, screen_center)):

                distance_mm = calculate_distance(best_rect.rect())
                last_valid_rect = best_rect.rect()
                last_valid_center = rect_center
                target_pos = rect_center
                tracking_mode = False

                # 绘制图形元素
                img.draw_rectangle(best_rect.rect(), color=(255, 0, 0), thickness=2)
                img.draw_circle(rect_center[0], rect_center[1], 5, color=(255, 0, 0), fill=True)
                img.draw_line(screen_center[0], screen_center[1],
                            target_pos[0], target_pos[1],
                            color=(0, 255, 0), thickness=2)
                img.draw_circle(screen_center[0], screen_center[1], 5, color=(0, 0, 255), fill=True)

                # 使用draw_string_advanced显示调试信息
                img.draw_string_advanced(10, 10, f"距离: {distance_mm:.1f}mm",
                                      color=(255,255,255), scale=2, mono_space=False)
                img.draw_string_advanced(10, 50, f"矩形中心: {target_pos}",
                                      color=(255,255,255), scale=1.5, mono_space=False)

                send_uart_data(screen_center, target_pos, distance_mm)
                img_okcount += 1
                return True

        # 矩形检测失败时使用亮点追踪
        if last_valid_rect:
            x1, y1, w, h = last_valid_rect
            try:
                brightest_x, brightest_y, max_brightness = find_brightest_spot(
                    gray, roi_rect=(x1, y1, w, h))

                if max_brightness > THRESHOLD_VALUES["BRIGHT_SPOT_THRESHOLD"]:
                    estimated_distance = calculate_distance(last_valid_rect) * 0.9

                    # 绘制追踪元素
                    img.draw_circle(brightest_x, brightest_y, 8, color=(255, 255, 0), fill=True)
                    img.draw_line(screen_center[0], screen_center[1],
                                brightest_x, brightest_y,
                                color=(255, 165, 0), thickness=2)

                    # 使用draw_string_advanced显示信息
                    img.draw_string_advanced(10, 10, "追踪模式", color=(255,255,0), scale=2, mono_space=False)
                    img.draw_string_advanced(10, 50, f"亮点坐标: ({brightest_x},{brightest_y})",
                                          color=(255,255,255), scale=1.5, mono_space=False)
                    img.draw_string_advanced(10, 90, f"估算距离: {estimated_distance:.1f}mm",
                                          color=(255,255,255), scale=1.2, mono_space=False)

                    send_uart_data(screen_center, (brightest_x, brightest_y), estimated_distance)
                    return True
            except Exception as e:
                print(f"亮点追踪错误: {e}")

        # 使用draw_string_advanced显示未检测到目标
        img.draw_string_advanced(20, 20, "未检测到目标", color=(255,0,0), scale=3, mono_space=False)
        return False
    except Exception as e:
        print(f"检测错误: {e}")
        return False

def main_loop():
    fps = time.clock()
    while running:
        try:
            fps.tick()
            os.exitpoint()

            img = sensor.snapshot()
            detect_outer_rectangle(img)

            # 使用draw_string_advanced显示帧率
            img.draw_string_advanced(DISPLAY_WIDTH-150, DISPLAY_HEIGHT-40,
                                  f"FPS: {fps.fps():.1f}",
                                  color=(255,255,255), scale=2, mono_space=False)
            Display.show_image(img)
            gc.collect()

        except KeyboardInterrupt:
            global running
            running = False
        except Exception as e:
            print(f"主循环错误: {e}")
            time.sleep(0.5)

def main():
    os.exitpoint(os.EXITPOINT_ENABLE)
    try:
        camera_init()
        main_loop()
    except Exception as e:
        print(f"主程序错误: {e}")
    finally:
        camera_deinit()
        print("程序结束")

if __name__ == "__main__":
    main()
