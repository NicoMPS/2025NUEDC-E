import time, os, gc, sys
from media.sensor import *
from media.display import *
from media.media import *
from machine import TOUCH

# ================ 系统配置 ================
DISPLAY_WIDTH = 800
DISPLAY_HEIGHT = 480
DETECT_WIDTH = ALIGN_UP(600, 16)
DETECT_HEIGHT = 480

# ================ 阈值参数配置 ================
THRESHOLD_CONFIG = {
    "BLACK_GRAY_THRESHOLD": {
        "name": "边框黑度",
        "min_val": 0,
        "max_val": 255,
        "default": 100,
        "color": (255, 0, 0)
    },
    "CENTER_GRAY_THRESHOLD": {
        "name": "中心亮度",
        "min_val": 80,
        "max_val": 150,
        "default": 110,
        "color": (0, 255, 0)
    },
    "RECT_DETECT_THRESHOLD": {
        "name": "检测灵敏度",
        "min_val": 1000,
        "max_val": 3000,
        "default": 2000,
        "color": (0, 0, 255)
    }
}

# ================ 功能按钮 ================
FUNCTION_BUTTONS = {
    "重置": {"rect": (620, 100, 150, 60), "color": (255, 165, 0)},
    "保存": {"rect": (620, 180, 150, 60), "color": (0, 200, 0)},
    "模式切换": {"rect": (620, 260, 150, 60), "color": (200, 50, 50)}
}

# ================ 全局变量 ================
sensor = None
tp = None
current_values = {key: cfg["default"] for key, cfg in THRESHOLD_CONFIG.items()}
adjust_mode = True
running = True

def camera_init():
    global sensor, tp
    try:
        sensor = Sensor(width=DETECT_WIDTH, height=DETECT_HEIGHT)
        sensor.reset()
        sensor.set_framesize(width=DETECT_WIDTH, height=DETECT_HEIGHT)
        sensor.set_pixformat(Sensor.RGB565)

        Display.init(Display.ST7701, width=DISPLAY_WIDTH, height=DISPLAY_HEIGHT, fps=15)
        MediaManager.init()

        tp = TOUCH(0)
        sensor.run()
        print("摄像头初始化成功")
    except Exception as e:
        print(f"摄像头初始化失败: {e}")
        raise

def camera_deinit():
    global sensor, tp
    try:
        if sensor: sensor.stop()
        if tp: tp.deinit()
        Display.deinit()
        MediaManager.deinit()
    except Exception as e:
        print(f"资源释放错误: {e}")

def draw_threshold_sliders(img):
    """绘制阈值调节滑块"""
    img.draw_string(20, 20, "阈值调节面板", color=(255, 255, 0), scale=3)
    img.draw_rectangle(50, 50, 500, 400, color=(30, 30, 30), fill=True, alpha=150)

    for i, (key, cfg) in enumerate(THRESHOLD_CONFIG.items()):
        y_pos = 100 + i * 120
        track_x1, track_x2 = 100, 500
        ratio = (current_values[key] - cfg["min_val"]) / (cfg["max_val"] - cfg["min_val"])
        thumb_x = track_x1 + int(ratio * (track_x2 - track_x1))

        img.draw_string(track_x1, y_pos - 30, f"{cfg['name']}: {current_values[key]}",
                       color=(255, 255, 255), scale=2.5)
        img.draw_line(track_x1, y_pos, track_x2, y_pos, color=(200, 200, 200), thickness=10)
        img.draw_circle(thumb_x, y_pos, 25, color=cfg["color"], fill=True)

        img.draw_string(track_x1 - 50, y_pos + 15, str(cfg["min_val"]),
                       color=(200, 200, 200), scale=1.5)
        img.draw_string(track_x2 + 20, y_pos + 15, str(cfg["max_val"]),
                       color=(200, 200, 200), scale=1.5)

def draw_function_buttons(img):
    """绘制功能按钮"""
    for name, btn in FUNCTION_BUTTONS.items():
        img.draw_rectangle(btn["rect"][0], btn["rect"][1],
                          btn["rect"][2], btn["rect"][3],
                          color=btn["color"], fill=True)
        text_x = btn["rect"][0] + (btn["rect"][2] - len(name)*20) // 2
        img.draw_string(text_x, btn["rect"][1] + 15,
                       name, color=(255, 255, 255), scale=2.5)

def handle_touch():
    """处理触摸事件（已修复全局变量问题）"""
    global adjust_mode

    try:
        p = tp.read(1)
        if p == (): return False

        x, y = p[0].x, p[0].y
        print(f"触摸坐标: ({x}, {y})")

        # 检查滑块触摸
        if adjust_mode:
            for i, (key, cfg) in enumerate(THRESHOLD_CONFIG.items()):
                y_pos = 100 + i * 120
                if 100 <= x <= 500 and y_pos - 30 <= y <= y_pos + 30:
                    new_val = int(cfg["min_val"] + (x - 100)/400 * (cfg["max_val"] - cfg["min_val"]))
                    current_values[key] = max(cfg["min_val"], min(cfg["max_val"], new_val))
                    print(f"{cfg['name']} 更新为 {current_values[key]}")
                    return True

        # 检查功能按钮触摸
        for name, btn in FUNCTION_BUTTONS.items():
            rect = btn["rect"]
            if rect[0] <= x <= rect[0] + rect[2] and rect[1] <= y <= rect[1] + rect[3]:
                if name == "重置":
                    for key in current_values:
                        current_values[key] = THRESHOLD_CONFIG[key]["default"]
                    print("重置所有阈值")
                elif name == "保存":
                    print("保存当前阈值设置")
                elif name == "模式切换":
                    adjust_mode = not adjust_mode
                    print("进入调整模式" if adjust_mode else "进入检测模式")
                return True

        return False
    except Exception as e:
        print(f"触摸处理错误: {e}")
        return False

def detect_outer_rectangle(img):
    """使用当前阈值检测外接矩形"""
    try:
        if img is None:
            print("错误: 输入图像为空")
            return False

        gray = img.to_grayscale()
        counts = gray.find_rects(threshold=current_values["RECT_DETECT_THRESHOLD"])

        best_rect = None
        max_area = 0
        for r in counts:
            x, y, w, h = r.rect()
            area = w * h
            if area > max_area:
                max_area = area
                best_rect = r

        if best_rect:
            x1, y1 = best_rect.rect()[0], best_rect.rect()[1]
            x2, y2 = x1 + best_rect.rect()[2], y1 + best_rect.rect()[3]
            center_x, center_y = (x1 + x2) // 2, (y1 + y2) // 2
            screen_center_x, screen_center_y = img.width()//2, img.height()//2

            # 标准坐标输出
            print("=== 目标坐标 ===")
            print(f"左上: ({x1}, {y1}) 右上: ({x2}, {y1})")
            print(f"左下: ({x1}, {y2}) 右下: ({x2}, {y2})")
            print(f"中心: ({center_x}, {center_y})")
            print(f"偏移: ΔX={center_x-screen_center_x} ΔY={center_y-screen_center_y}")
            print("===============")

            # 绘制检测结果
            img.draw_rectangle(best_rect.rect(), color=(255, 0, 0), thickness=2)
            img.draw_circle(center_x, center_y, 5, color=(255, 0, 0), fill=True)
            img.draw_line(center_x, center_y, screen_center_x, screen_center_y,
                         color=(0, 255, 0), thickness=2)
            img.draw_circle(screen_center_x, screen_center_y, 5, color=(0, 0, 255), fill=True)
            return True

        print("未检测到有效目标")
        return False
    except Exception as e:
        print(f"检测错误: {e}")
        return False

def main_loop():
    fps = time.clock()
    while running:
        try:
            fps.tick()
            os.exitpoint()

            img = sensor.snapshot()
            handle_touch()

            if adjust_mode:
                draw_threshold_sliders(img)
                draw_function_buttons(img)
            else:
                if detect_outer_rectangle(img):
                    img.draw_string(20, 20, "检测成功!", color=(0, 255, 0), scale=3)
                else:
                    img.draw_string(20, 20, "未检测到目标", color=(255, 0, 0), scale=3)

                img.draw_string(20, 60, f"边框阈值: {current_values['BLACK_GRAY_THRESHOLD']}",
                              color=(255, 255, 255), scale=2)
                img.draw_string(20, 100, f"中心阈值: {current_values['CENTER_GRAY_THRESHOLD']}",
                              color=(255, 255, 255), scale=2)
                img.draw_string(20, 140, f"检测灵敏度: {current_values['RECT_DETECT_THRESHOLD']}",
                              color=(255, 255, 255), scale=2)
                draw_function_buttons(img)

            img.draw_string(DISPLAY_WIDTH - 150, DISPLAY_HEIGHT - 40,
                          f"FPS: {fps.fps():.1f}", color=(255, 255, 255), scale=2)
            Display.show_image(img)
            gc.collect()

        except KeyboardInterrupt:
            global running
            running = False
        except Exception as e:
            print(f"主循环错误: {e}")
            time.sleep(0.5)

def main():
    os.exitpoint(os.EXITPOINT_ENABLE)
    try:
        camera_init()
        main_loop()
    except Exception as e:
        print(f"主程序错误: {e}")
    finally:
        camera_deinit()
        print("程序结束")

if __name__ == "__main__":
    main()
