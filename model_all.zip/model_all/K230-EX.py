import time, os, gc, sys, math
from media.sensor import *
from media.display import *
from media.media import *
from machine import UART, FPIOA, TOUCH

# 图像尺寸（较小尺寸更利于提升帧率）
DETECT_WIDTH = ALIGN_UP(320, 16)  # 按16字节对齐宽度
DETECT_HEIGHT = 240
sensor = None

# ================ A4纸物理尺寸(mm) ================
A4_WIDTH_MM = 210  # 短边
A4_HEIGHT_MM = 297  # 长边

# ================ 摄像头参数 ================
ACTUAL_FOCAL_LENGTH_MM = 3.6  # 实际焦距(mm)
SENSOR_WIDTH_MM = 4.8         # 传感器宽度(mm)
SENSOR_HEIGHT_MM = 3.6        # 传感器高度(mm)

# ================ 串口配置 ================
UART_PORT = 2
UART_BAUDRATE = 115200
UART_TX_PIN = 11
UART_RX_PIN = 12
HEADER = 0x55
CHECKSUM = 0x77
FOOTER = 0x44

# 灰度阈值：低于50的像素为黑色，高于205的为白色（可根据场景调整）
# 阈值范围为(0-255)，范围越窄，黑白对比越强烈
gray_threshold = [(89, 178)]  # 仅保留此范围内的灰度为白色，其他为黑色

# A4纸标准比例(长边:短边=1.414:1)及容差范围
A4_RATIO = 297/210  # A4纸长边与短边的比例(约为1.414)
RATIO_TOLERANCE = 0.18  # 比例容差范围
ANGLE_TOLERANCE = 20    # 倾斜角度容差（度），允许矩形倾斜的最大角度

# 矩形尺寸限制（像素）
MIN_RECT_AREA = 2000    # 最小面积（像素²）
MAX_RECT_AREA = 20000   # 最大面积（像素²）

# 全局变量
uart = None
last_send_time = 0

def calculate_rotated_rect_properties(corners):
    """计算旋转矩形的属性（宽、高、角度、中心点）"""
    # 计算中心点
    center_x = sum(p[0] for p in corners) / 4
    center_y = sum(p[1] for p in corners) / 4

    # 计算相邻角点之间的距离
    distances = []
    for i in range(4):
        x1, y1 = corners[i]
        x2, y2 = corners[(i+1)%4]
        dist = ((x2-x1)**2 + (y2-y1)**2) ** 0.5
        distances.append(dist)

    # 假设较长的两边为矩形的长，较短的两边为矩形的宽
    sorted_dists = sorted(distances)
    width = (sorted_dists[0] + sorted_dists[1]) / 2  # 取两个短边的平均值
    height = (sorted_dists[2] + sorted_dists[3]) / 2 # 取两个长边的平均值

    # 计算倾斜角度
    # 选择最长的边，计算其与水平线的夹角
    max_dist_idx = distances.index(max(distances))
    x1, y1 = corners[max_dist_idx]
    x2, y2 = corners[(max_dist_idx+1)%4]
    angle = math.atan2(y2-y1, x2-x1) * 180 / math.pi

    return width, height, angle, (center_x, center_y)

def calculate_distance_and_position(rect, img_width, img_height):
    """
    计算距离和物理位置(优化版)
    参数:
        rect: 检测到的矩形 (x,y,w,h)
        img_width: 图像宽度(像素)
        img_height: 图像高度(像素)
    返回:
        (distance_mm, center_x_mm, center_y_mm)
    """
    x, y, w, h = rect

    # 计算焦距像素值(基于传感器物理尺寸和图像分辨率)
    focal_length_px = (ACTUAL_FOCAL_LENGTH_MM / SENSOR_WIDTH_MM) * DETECT_WIDTH

    # 使用A4纸长边和短边分别计算距离，取平均值
    distance_mm_width = (A4_WIDTH_MM * focal_length_px) / w
    distance_mm_height = (A4_HEIGHT_MM * focal_length_px) / h
    distance_mm = (distance_mm_width + distance_mm_height) / 2
    distance_mm = max(500, min(1600, distance_mm))  # 限制在500-1600mm范围内

    # 计算物理坐标(mm) - 保持原始方向
    center_x_px = x + w/2  # 直接使用x坐标，左上角为原点
    center_y_px = y + h/2  # 直接使用y坐标，左上角为原点
    center_x_mm = (center_x_px * A4_WIDTH_MM) / w
    center_y_mm = (center_y_px * A4_HEIGHT_MM) / h

    return distance_mm, center_x_mm, center_y_mm

def send_uart_data(screen_center, rect_center, distance_mm, physical_x, physical_y):
    """通过UART2发送数据（16进制格式）"""
    global uart, last_send_time

    current_time = time.ticks_ms()
    if current_time - last_send_time < 20:  # 50Hz控制
        return False

    if not uart:
        return False

    # 将坐标转换为整数（像素坐标） - 保持原始方向
    sc_x = int(screen_center[0])  # 屏幕中心X
    sc_y = int(screen_center[1])  # 屏幕中心Y
    rc_x = int(rect_center[0])    # 矩形中心X
    rc_y = int(rect_center[1])    # 矩形中心Y
    dist = int(distance_mm)
    phy_x = int(physical_x * 10)  # 放大10倍保持精度
    phy_y = int(physical_y * 10)

    # 16进制数据包格式：
    # 包头(1B) + 屏幕中心XY(各2B) + 矩形中心XY(各2B) + 距离(2B) + 物理坐标XY(各2B) + 校验和(1B) + 包尾(1B)
    data = bytearray([
        HEADER,
        (sc_x >> 8) & 0xFF, sc_x & 0xFF,  # 屏幕中心X
        (sc_y >> 8) & 0xFF, sc_y & 0xFF,  # 屏幕中心Y
        (rc_x >> 8) & 0xFF, rc_x & 0xFF,  # 矩形中心X
        (rc_y >> 8) & 0xFF, rc_y & 0xFF,  # 矩形中心Y
        (dist >> 8) & 0xFF, dist & 0xFF,   # 距离(mm)
        (phy_x >> 8) & 0xFF, phy_x & 0xFF, # 物理X坐标(x10)
        (phy_y >> 8) & 0xFF, phy_y & 0xFF, # 物理Y坐标(x10)
        CHECKSUM,
        FOOTER
    ])

    try:
        uart.write(data)
        last_send_time = current_time
        print(f"[UART] 发送: {[hex(b) for b in data]}")
        print(f"屏幕中心: ({sc_x},{sc_y}) 矩形中心: ({rc_x},{rc_y})")
        print(f"距离: {distance_mm:.1f}mm 物理坐标: X={physical_x:.1f}mm Y={physical_y:.1f}mm")
        return True
    except Exception as e:
        print(f"串口发送失败: {e}")
        return False

def is_a4_rect(rect):
    """判断矩形是否符合A4纸比例，考虑倾斜情况"""
    corners = rect.corners()
    width, height, angle, center = calculate_rotated_rect_properties(corners)

    # 计算宽高比
    ratio = max(width, height) / min(width, height) if min(width, height) != 0 else 0

    # 检查角度是否在允许范围内（相对于横放或竖放）
    angle_from_horizontal = abs(angle) % 90
    angle_ok = (angle_from_horizontal <= ANGLE_TOLERANCE) or \
               (abs(angle_from_horizontal - 90) <= ANGLE_TOLERANCE)

    # 判断是否符合A4比例且角度在允许范围内
    return (A4_RATIO - RATIO_TOLERANCE) <= ratio <= (A4_RATIO + RATIO_TOLERANCE) and angle_ok

def camera_init():
    global sensor, uart
    # 初始化传感器，直接输出灰度图（减少色彩处理）
    sensor = Sensor(id = 2, width=DETECT_WIDTH, height=DETECT_HEIGHT)
    sensor.reset()
    sensor.set_vflip(True)
    # 设置输出尺寸
    sensor.set_framesize(width=DETECT_WIDTH, height=DETECT_HEIGHT)
    # 关键：设置像素格式为灰度图（单通道，无色彩信息）
    sensor.set_pixformat(Sensor.GRAYSCALE)
    # 初始化显示（输出到IDE）
    Display.init(Display.VIRT, width=DETECT_WIDTH, height=DETECT_HEIGHT, fps=100, to_ide=True)
    MediaManager.init()
    sensor.run()

    # 初始化串口
    print("正在初始化UART2...")
    fpioa = FPIOA()
    fpioa.set_function(UART_TX_PIN, FPIOA.UART2_TXD)
    fpioa.set_function(UART_RX_PIN, FPIOA.UART2_RXD)

    uart = UART(UART_PORT, baudrate=UART_BAUDRATE)
    uart.init(
        baudrate=UART_BAUDRATE,
        bits=UART.EIGHTBITS,
        parity=UART.PARITY_NONE,
        stop=UART.STOPBITS_ONE
    )
    print(f"UART2初始化完成，波特率: {UART_BAUDRATE}")

def camera_deinit():
    global sensor, uart
    sensor.stop()
    if uart: uart.deinit()
    Display.deinit()
    os.exitpoint(os.EXITPOINT_ENABLE_SLEEP)
    time.sleep_ms(100)
    MediaManager.deinit()

def capture_picture():
    fps = time.clock()
    while True:
        fps.tick()
        try:
            os.exitpoint()
            global sensor
            img = sensor.snapshot()  # 获取灰度图

            # 二值化处理：仅保留阈值范围内的像素为白色，其他为黑色
            # 此时图像仅含黑白两色，完全无其他色彩
            img.binary(gray_threshold, invert=False)

            # 矩形检测：在二值化后的黑白图像上检测矩形
            # threshold参数控制矩形边缘检测的敏感度，值越大检测越严格
            detected = False
            for r in img.find_rects(threshold = 9000):
                # 获取矩形角点
                corners = r.corners()

                # 计算矩形面积
                x, y, w, h = r.rect()
                area = w * h

                # 检查矩形尺寸是否在允许范围内
                if area < MIN_RECT_AREA or area > MAX_RECT_AREA:
                    continue

                # 检查是否符合A4纸比例（考虑倾斜）
                if is_a4_rect(r):
                    # 获取旋转矩形的属性
                    width, height, angle, (center_x, center_y) = calculate_rotated_rect_properties(corners)
                    center_x, center_y = int(center_x), int(center_y)

                    # 计算屏幕中心点
                    screen_center = (img.width() // 2, img.height() // 2)

                    # 计算距离和物理位置
                    distance_mm, physical_x, physical_y = calculate_distance_and_position(
                        (x, y, w, h), img.width(), img.height())

                    # 发送串口数据
                    send_uart_data(screen_center, (center_x, center_y), distance_mm, physical_x, physical_y)

                    # 绘制红色矩形框
                    img.draw_rectangle([v for v in r.rect()], color = (255, 0, 0))
                    # 绘制绿色角点标记
                    for p in corners:
                        img.draw_circle(p[0], p[1], 5, color = (0, 255, 0))
                    # 绘制中心点十字标记
                    cross_size = 3
                    img.draw_line(center_x - cross_size, center_y, center_x + cross_size, center_y, color=(255, 0, 0), thickness=2)
                    img.draw_line(center_x, center_y - cross_size, center_x, center_y + cross_size, color=(255, 0, 0), thickness=2)

                    # 输出矩形信息
                    print(f"A4纸矩形: 宽={width:.1f}, 高={height:.1f}, 角度={angle:.1f}°, 中心点: ({center_x}, {center_y}), 面积: {area}")
                    detected = True
                    break  # 只处理第一个检测到的A4纸

            Display.show_image(img)
            img = None  # 释放图像内存
            gc.collect()  # 主动垃圾回收
            print(f"FPS: {fps.fps()}")  # 输出实时帧率
        except KeyboardInterrupt:
            print("用户停止")
            break
        except Exception as e:
            print(f"错误: {e}")
            break

def main():
    os.exitpoint(os.EXITPOINT_ENABLE)
    camera_is_init = False
    try:
        print("初始化相机（黑白模式）...")
        camera_init()
        camera_is_init = True
        print("开始捕获画面（带A4纸检测）...")
        capture_picture()
    except Exception as e:
        print(f"主程序错误: {e}")
    finally:
        if camera_is_init:
            print("释放相机资源...")
            camera_deinit()

if __name__ == "__main__":
    main()
