import time, os, gc, sys
import math
from media.sensor import *
from media.display import *
from media.media import *
from machine import UART, FPIOA, TOUCH

# ================ 系统配置 ================
DISPLAY_WIDTH = 800
DISPLAY_HEIGHT = 480
DETECT_WIDTH = ALIGN_UP(500, 16)
DETECT_HEIGHT = 400

# ================ A4纸物理尺寸(mm) ================
A4_WIDTH_MM = 297
A4_HEIGHT_MM = 210

# ================ 相机参数 ================
FOCAL_LENGTH_PX = 500
SENSOR_WIDTH_MM = 4.8
SENSOR_HEIGHT_MM = 3.6

# ================ 阈值配置 ================
THRESHOLD_CONFIG = {
    "BLACK_GRAY_THRESHOLD": {
        "name": "边框黑度",
        "min_val": 0,
        "max_val": 255,
        "default": 149,
        "color": (255, 0, 0)
    },
    "CENTER_GRAY_THRESHOLD": {
        "name": "中心亮度",
        "min_val": 0,
        "max_val": 255,
        "default": 128,
        "color": (0, 255, 0)
    },
    "RECT_DETECT_THRESHOLD": {
        "name": "检测灵敏度",
        "min_val": 1000,
        "max_val": 5000,
        "default": 2500,
        "color": (0, 0, 255)
    },
    "BRIGHT_SPOT_THRESHOLD": {
        "name": "亮点阈值",
        "min_val": 150,
        "max_val": 255,
        "default": 200,
        "color": (255, 255, 0)
    }
}

# ================ 功能按钮配置 ================
FUNCTION_BUTTONS = {
    "重置": {"rect": (620, 100, 150, 60), "color": (255, 165, 0)},
    "保存": {"rect": (620, 180, 150, 60), "color": (0, 200, 0)},
    "退出": {"rect": (620, 260, 150, 60), "color": (200, 50, 50)}
}

# ================ 矩形宽高比限制 ================
MIN_ASPECT_RATIO = 1.1
MAX_ASPECT_RATIO = 1.8

# ================ UART配置 ================
UART_PORT = 2
UART_BAUDRATE = 115200
UART_TX_PIN = 11
UART_RX_PIN = 12
HEADER = 0x55
CHECKSUM = 0x77
FOOTER = 0x44

# ================ 全局变量 ================
sensor = None
uart = None
tp = None
running = True
img_okcount = 0
last_send_time = 0
adjust_mode = False
current_values = {}
last_touch_time = 0
TOUCH_DEBOUNCE = 300  # 触摸消抖时间(ms)
last_valid_rect = None  # 新增：用于追踪模式下保存上次有效的矩形
background_img = Image(DISPLAY_WIDTH, DISPLAY_HEIGHT, Image.RGB565)  # 底层背景图像
foreground_img = Image(DISPLAY_WIDTH, DISPLAY_HEIGHT, Image.RGB565)  # 顶层调节界面
foreground_img.clear((0, 0, 0))  # 初始化透明黑色

# ================ 配置文件路径 ================
CONFIG_FILE = "/sd/threshold_config.txt"

def load_threshold_config():
    """从SD卡加载保存的阈值配置"""
    global current_values
    try:
        with open(CONFIG_FILE, 'r') as f:
            for line in f:
                key, val = line.strip().split('=')
                if key in THRESHOLD_CONFIG:
                    current_values[key] = int(val)
        print("从SD卡加载阈值配置成功")
    except Exception as e:
        print(f"加载配置失败，使用默认值: {e}")
        current_values = {key: cfg["default"] for key, cfg in THRESHOLD_CONFIG.items()}

def save_threshold_config():
    """保存当前阈值配置到SD卡"""
    try:
        with open(CONFIG_FILE, 'w') as f:
            for key, val in current_values.items():
                f.write(f"{key}={val}\n")
        print("阈值配置已保存到SD卡")
    except Exception as e:
        print(f"保存配置失败: {e}")

def camera_init():
    global sensor, uart, tp
    try:
        print("正在初始化相机...")
        sensor = Sensor(width=DETECT_WIDTH, height=DETECT_HEIGHT)
        sensor.reset()
        sensor.set_framesize(width=DETECT_WIDTH, height=DETECT_HEIGHT)
        sensor.set_pixformat(Sensor.RGB565)

        # 初始化UART
        print("正在初始化UART2...")
        fpioa = FPIOA()
        fpioa.set_function(UART_TX_PIN, FPIOA.UART2_TXD)
        fpioa.set_function(UART_RX_PIN, FPIOA.UART2_RXD)

        uart = UART(UART_PORT, baudrate=UART_BAUDRATE)
        uart.init(
            baudrate=UART_BAUDRATE,
            bits=UART.EIGHTBITS,
            parity=UART.PARITY_NONE,
            stop=UART.STOPBITS_ONE
        )
        print(f"UART2初始化完成，波特率: {UART_BAUDRATE}")

        # 初始化触摸屏
        tp = TOUCH(0)

        # 初始化显示 - 准备两个图层
        Display.init(Display.ST7701, width=DISPLAY_WIDTH, height=DISPLAY_HEIGHT, fps=30)
        MediaManager.init()

        # 绑定底层图层(LAYER_VIDEO)用于显示背景画面
        MediaManager.bind_layer(LAYER_VIDEO1, 0, 0, DISPLAY_WIDTH, DISPLAY_HEIGHT)

        # 绑定顶层图层(LAYER_OSD0)用于显示调节界面
        MediaManager.bind_layer(LAYER_OSD0, 0, 0, DISPLAY_WIDTH, DISPLAY_HEIGHT)

        # 设置顶层图层透明度 (0-255, 255为完全不透明)
        MediaManager.set_transparency(LAYER_OSD0, 230)

        sensor.run()
        print("相机初始化完成")
    except Exception as e:
        print(f"相机初始化失败: {e}")
        raise

def camera_deinit():
    global sensor, uart, tp
    try:
        if sensor: sensor.stop()
        if uart: uart.deinit()
        Display.deinit()
        MediaManager.deinit()
    except Exception as e:
        print(f"相机释放错误: {e}")

def calculate_distance(rect):
    """计算到矩形的距离"""
    _, _, w, h = rect
    distance_mm = (A4_HEIGHT_MM * FOCAL_LENGTH_PX) / h
    return max(500, min(1600, distance_mm))

def send_uart_data(rect_center_x, rect_center_y, distance_mm):
    """通过UART2发送数据(简化版)"""
    global uart, last_send_time

    current_time = time.ticks_ms()
    if current_time - last_send_time < 20:  # 50Hz控制
        return False

    if not uart:
        return False

    # 坐标转换为0.1mm单位
    rect_x_int = int(rect_center_x * 10)
    rect_y_int = int(rect_center_y * 10)
    distance_int = int(distance_mm)

    data = bytearray([
        HEADER,
        (rect_x_int >> 8) & 0xFF, rect_x_int & 0xFF,
        (rect_y_int >> 8) & 0xFF, rect_y_int & 0xFF,
        0x00, 0x00,  # 镜头坐标X(固定为0)
        0x00, 0x00,  # 镜头坐标Y(固定为0)
        (distance_int >> 8) & 0xFF, distance_int & 0xFF,
        CHECKSUM,
        FOOTER
    ])

    try:
        uart.write(data)
        last_send_time = current_time
        print(f"[UART] 发送: 距离={distance_mm:.1f}mm")
        return True
    except Exception as e:
        print(f"串口发送失败: {e}")
        return False

def draw_threshold_sliders(img):
    """绘制阈值调节滑块界面到顶层图层"""
    img.clear()  # 清空当前图层
    img.draw_rectangle(0, 0, DISPLAY_WIDTH, DISPLAY_HEIGHT, color=(30, 30, 30), fill=True, alpha=220)

    # 绘制标题
    img.draw_string(20, 20, "阈值调节面板", color=(255, 255, 0), scale=3)

    # 绘制滑块区域背景
    img.draw_rectangle(50, 50, 500, 400, color=(50, 50, 50), fill=True)

    # 绘制每个阈值滑块
    for i, (key, cfg) in enumerate(THRESHOLD_CONFIG.items()):
        y_pos = 100 + i * 80
        track_x1, track_x2 = 100, 500

        # 计算滑块位置
        ratio = (current_values[key] - cfg["min_val"]) / (cfg["max_val"] - cfg["min_val"])
        thumb_x = track_x1 + int(ratio * (track_x2 - track_x1))

        # 绘制参数名称
        img.draw_string(track_x1, y_pos - 30,
                      f"{cfg['name']}: {current_values[key]}",
                      color=(255, 255, 255), scale=2)

        # 绘制滑轨
        img.draw_line(track_x1, y_pos, track_x2, y_pos,
                     color=(200, 200, 200), thickness=8)

        # 绘制滑块
        img.draw_circle(thumb_x, y_pos, 20, color=cfg["color"], fill=True)

        # 绘制最小值/最大值标签
        img.draw_string(track_x1 - 50, y_pos + 15, str(cfg["min_val"]),
                       color=(200, 200, 200), scale=1.5)
        img.draw_string(track_x2 + 20, y_pos + 15, str(cfg["max_val"]),
                       color=(200, 200, 200), scale=1.5)

def draw_function_buttons(img):
    """在顶层图层上绘制功能按钮"""
    for name, btn in FUNCTION_BUTTONS.items():
        # 绘制按钮背景
        img.draw_rectangle(btn["rect"][0], btn["rect"][1],
                         btn["rect"][2], btn["rect"][3],
                         color=btn["color"], fill=True)

        # 绘制按钮文字
        text_x = btn["rect"][0] + (btn["rect"][2] - len(name)*20) // 2
        img.draw_string(text_x, btn["rect"][1] + 15,
                       name, color=(255, 255, 255), scale=2)

    # 绘制返回按钮
    img.draw_rectangle(620, 400, 150, 60, color=(0, 150, 255), fill=True)
    img.draw_string(635, 415, "返回检测", color=(255, 255, 255), scale=2)

def handle_touch():
    """处理触摸事件(带消抖)"""
    global adjust_mode, last_touch_time, last_valid_rect

    current_time = time.ticks_ms()
    if current_time - last_touch_time < TOUCH_DEBOUNCE:
        return False

    p = tp.read(1)
    if p == (): return False

    x, y = p[0].x, p[0].y
    last_touch_time = current_time
    print(f"触摸事件: ({x},{y})")

    # 检查滑块触摸
    if adjust_mode:
        for i, (key, cfg) in enumerate(THRESHOLD_CONFIG.items()):
            y_pos = 100 + i * 80
            if 100 <= x <= 500 and y_pos - 30 <= y <= y_pos + 30:
                new_val = int(cfg["min_val"] + (x - 100) / 400 * (cfg["max_val"] - cfg["min_val"]))
                current_values[key] = max(cfg["min_val"], min(cfg["max_val"], new_val))
                print(f"更新阈值: {cfg['name']}={current_values[key]}")
                # 实时更新调节界面
                draw_threshold_sliders(foreground_img)
                draw_function_buttons(foreground_img)
                MediaManager.show_image(LAYER_OSD0, foreground_img)
                return True

    # 检查功能按钮触摸
    for name, btn in FUNCTION_BUTTONS.items():
        rect = btn["rect"]
        if rect[0] <= x <= rect[0] + rect[2] and rect[1] <= y <= rect[1] + rect[3]:
            if name == "重置":
                for key in current_values:
                    current_values[key] = THRESHOLD_CONFIG[key]["default"]
                print("重置所有阈值")
                # 更新界面
                draw_threshold_sliders(foreground_img)
                draw_function_buttons(foreground_img)
                MediaManager.show_image(LAYER_OSD0, foreground_img)
                return True
            elif name == "保存":
                save_threshold_config()
                print("保存当前阈值设置")
                return True
            elif name == "退出":
                adjust_mode = False
                # 禁用顶层图层
                MediaManager.clear(LAYER_OSD0)
                print("退出调整模式")
                return True

    # 检查进入调整按钮(非调整模式下)
    if not adjust_mode and 620 <= x <= 770 and 400 <= y <= 460:
        adjust_mode = True
        # 启用并更新顶层图层
        draw_threshold_sliders(foreground_img)
        draw_function_buttons(foreground_img)
        MediaManager.show_image(LAYER_OSD0, foreground_img)
        print("进入调整模式")
        return True

    return False

def detect_outer_rectangle(img):
    """检测外接矩形并计算坐标"""
    global img_okcount, last_valid_rect

    try:
        if img is None:
            print("错误: 输入图像为空")
            return False

        img_width = img.width()
        img_height = img.height()
        screen_center = (img_width // 2, img_height // 2)

        gray = img.to_grayscale()
        counts = gray.find_rects(threshold=current_values["RECT_DETECT_THRESHOLD"])

        best_rect = None
        max_area = 0
        for r in counts:
            x, y, w, h = r.rect()
            area = w * h
            aspect_ratio = float(w) / h

            if MIN_ASPECT_RATIO < aspect_ratio < MAX_ASPECT_RATIO and area > max_area:
                max_area = area
                best_rect = r

        if best_rect:
            x1, y1 = best_rect.rect()[0], best_rect.rect()[1]
            x2, y2 = x1 + best_rect.rect()[2], y1 + best_rect.rect()[3]
            rect_center = ((x1 + x2) // 2, (y1 + y2) // 2)
            last_valid_rect = best_rect.rect()  # 保存有效矩形

            # 验证矩形有效性
            border_gray = gray.get_statistics(roi=(x1, y1, best_rect.rect()[2], 5)).mean()
            center_gray = gray.get_statistics(roi=(rect_center[0], rect_center[1], 4, 4)).mean()

            if (border_gray < current_values["BLACK_GRAY_THRESHOLD"] and
                center_gray > current_values["CENTER_GRAY_THRESHOLD"]):

                distance_mm = calculate_distance(best_rect.rect())

                # 在背景图层上绘制检测结果
                background_img.draw_rectangle(best_rect.rect(), color=(255, 0, 0), thickness=2)
                background_img.draw_circle(rect_center[0], rect_center[1], 5, color=(255, 0, 0), fill=True)
                background_img.draw_line(screen_center[0], screen_center[1],
                                      rect_center[0], rect_center[1],
                                      color=(0, 255, 0), thickness=2)
                background_img.draw_circle(screen_center[0], screen_center[1], 5, color=(0, 0, 255), fill=True)

                # 在背景图层上显示调试信息
                background_img.draw_string(10, 10, f"距离: {distance_mm:.1f}mm",
                                        color=(255,255,255), scale=2)
                background_img.draw_string(10, 50, f"矩形中心: {rect_center}",
                                        color=(255,255,255), scale=1.5)

                # 发送串口数据
                send_uart_data(rect_center[0], rect_center[1], distance_mm)
                img_okcount += 1
                return True

        # 矩形检测失败时使用亮点追踪
        if last_valid_rect:
            x1, y1, w, h = last_valid_rect
            brightest_x, brightest_y, max_brightness = find_brightest_spot(
                gray, roi_rect=(x1, y1, w, h))

            if max_brightness > current_values["BRIGHT_SPOT_THRESHOLD"]:
                estimated_distance = calculate_distance(last_valid_rect) * 0.9

                # 在背景图层上绘制追踪元素
                background_img.draw_circle(brightest_x, brightest_y, 8, color=(255, 255, 0), fill=True)
                background_img.draw_line(screen_center[0], screen_center[1],
                                      brightest_x, brightest_y,
                                      color=(255, 165, 0), thickness=2)

                background_img.draw_string(10, 10, "追踪模式", color=(255,255,0), scale=2)
                background_img.draw_string(10, 50, f"亮点坐标: ({brightest_x},{brightest_y})",
                                        color=(255,255,255), scale=1.5)
                background_img.draw_string(10, 90, f"估算距离: {estimated_distance:.1f}mm",
                                        color=(255,255,255), scale=1.2)

                send_uart_data(brightest_x, brightest_y, estimated_distance)
                return True

        background_img.draw_string(20, 20, "未检测到目标", color=(255,0,0), scale=3)
        return False
    except Exception as e:
        print(f"检测错误: {e}")
        return False

def main_loop():
    fps = time.clock()
    while running:
        try:
            fps.tick()
            os.exitpoint()

            # 获取原始摄像头图像
            raw_img = sensor.snapshot()

            # 清空背景图像并复制摄像头画面
            background_img.clear()
            background_img.draw_image(0, 0, raw_img.resize(DISPLAY_WIDTH, DISPLAY_HEIGHT))

            # 处理触摸事件
            handle_touch()

            # 在检测模式下执行检测
            if not adjust_mode:
                detect_outer_rectangle(raw_img)

                # 在背景图层上显示当前阈值设置
                background_img.draw_string(20, DISPLAY_HEIGHT - 140, f"边框阈值: {current_values['BLACK_GRAY_THRESHOLD']}",
                                        color=(255,255,255), scale=1.5)
                background_img.draw_string(20, DISPLAY_HEIGHT - 100, f"中心阈值: {current_values['CENTER_GRAY_THRESHOLD']}",
                                        color=(255,255,255), scale=1.5)
                background_img.draw_string(20, DISPLAY_HEIGHT - 60, f"检测灵敏度: {current_values['RECT_DETECT_THRESHOLD']}",
                                        color=(255,255,255), scale=1.5)

                # 在背景图层上绘制进入调整按钮
                background_img.draw_rectangle(620, 400, 150, 60, color=(0, 150, 255), fill=True)
                background_img.draw_string(635, 415, "调整阈值", color=(255,255,255), scale=2)

            # 在背景图层上显示帧率
            background_img.draw_string(DISPLAY_WIDTH-150, DISPLAY_HEIGHT-40,
                                     f"FPS: {fps.fps():.1f}", color=(255,255,255), scale=2)

            # 更新图层显示
            MediaManager.show_image(LAYER_VIDEO1, background_img)
            gc.collect()

        except KeyboardInterrupt:
            global running
            running = False
        except Exception as e:
            print(f"主循环错误: {e}")
            time.sleep(0.5)

def main():
    os.exitpoint(os.EXITPOINT_ENABLE)
    try:
        # 加载保存的阈值配置
        load_threshold_config()

        # 初始化硬件
        camera_init()

        # 主循环
        main_loop()
    except Exception as e:
        print(f"主程序错误: {e}")
    finally:
        camera_deinit()
        print("程序结束")

if __name__ == "__main__":
    main()
