import time, os, gc, sys, math
from media.sensor import *
from media.display import *
from media.media import *
from machine import UART, FPIOA

# 图像尺寸（较小尺寸更利于提升帧率）
DETECT_WIDTH = ALIGN_UP(160, 16)  # 按16字节对齐宽度
DETECT_HEIGHT = 120
sensor = None

# 灰度阈值：低于110高于170的像素为黑色（红色圆圈会变成黑色），中间为白色
gray_threshold = [(89, 178)]  # 仅保留此范围内的灰度为白色，其他为黑色 50/120

# A4纸标准比例及容差范围
A4_RATIO = 297/210  # 约为1.414
RATIO_TOLERANCE = 0.18
ANGLE_TOLERANCE = 20    # 倾斜角度容差（度）

# 矩形尺寸限制（像素）
MIN_RECT_AREA = 1000    # 最小面积（像素²）
MAX_RECT_AREA = 20000   # 最大面积（像素²）

# 圆形检测参数
MIN_CIRCLE_AREA = 100    # 最小圆形面积（像素²）
MAX_CIRCLE_AREA = 10000   # 最大圆形面积（像素²）
CIRCLE_THRESHOLD = 8000 # 圆形检测阈值

# ================ 矩形检测优化配置 ================
RECT_DETECT_THRESHOLD = 2500  # 矩形检测灵敏度
MIN_ASPECT_RATIO = 1.1        # 最小宽高比
MAX_ASPECT_RATIO = 1.8        # 最大宽高比
BORDER_GRAY_THRESHOLD = 149    # 边框黑度阈值
CENTER_GRAY_THRESHOLD = 128   # 中心亮度阈值

# ================ 串口配置 ================
UART_PORT = 2
UART_BAUDRATE = 115200
UART_TX_PIN = 11
UART_RX_PIN = 12
HEADER = 0x55
CHECKSUM = 0x77
FOOTER = 0x44

# ================ 全局变量 ================
uart = None
last_send_time = 0

def distance(x1, y1, x2, y2):
    """计算两点(x1,y1)和点(x2,y2)之间的欧氏距离"""
    dx = x2 - x1
    dy = y2 - y1
    return math.sqrt(dx*dx + dy*dy)

def order_corners(corners):
    """对四边形的四个角点进行排序，确保顺序为：[左上角, 右上角, 右下角, 左下角]"""
    sorted_x = sorted(corners, key=lambda p: p[0])
    left = sorted_x[:2]
    right = sorted_x[2:]
    left_sorted = sorted(left, key=lambda p: p[1])
    top_left, bottom_left = left_sorted
    right_sorted = sorted(right, key=lambda p: p[1])
    top_right, bottom_right = right_sorted
    return [top_left, top_right, bottom_right, bottom_left]

def calculate_perspective_transform(src_points, dst_width, dst_height):
    """计算透视变换矩阵"""
    dst_points = [
        [0, 0],
        [dst_width - 1, 0],
        [dst_width - 1, dst_height - 1],
        [0, dst_height - 1]
    ]

    matrix = []
    for i in range(4):
        x, y = src_points[i]
        u, v = dst_points[i]
        matrix.append([x, y, 1, 0, 0, 0, -u*x, -u*y, -u])
        matrix.append([0, 0, 0, x, y, 1, -v*x, -v*y, -v])

    A = []
    B = []
    for row in matrix:
        A.append(row[:8])
        B.append(-row[8])

    n = 8
    for i in range(n):
        max_row = i
        for j in range(i, n):
            if abs(A[j][i]) > abs(A[max_row][i]):
                max_row = j

        A[i], A[max_row] = A[max_row], A[i]
        B[i], B[max_row] = B[max_row], B[i]

        pivot = A[i][i]
        if abs(pivot) < 1e-8:
            return [[1, 0, 0], [0, 1, 0], [0, 0, 1]]

        for j in range(i, n):
            A[i][j] /= pivot
        B[i] /= pivot

        for j in range(n):
            if j != i and A[j][i] != 0:
                factor = A[j][i]
                for k in range(i, n):
                    A[j][k] -= factor * A[i][k]
                B[j] -= factor * B[i]

    transform = [
        [B[0], B[1], B[2]],
        [B[3], B[4], B[5]],
        [B[6], B[7], 1]
    ]
    return transform

def apply_perspective_transform(point, transform):
    """将点应用透视变换"""
    x, y = point
    x_new = transform[0][0] * x + transform[0][1] * y + transform[0][2]
    y_new = transform[1][0] * x + transform[1][1] * y + transform[1][2]
    w = transform[2][0] * x + transform[2][1] * y + transform[2][2]

    if abs(w) < 1e-8:
        return (x, y)

    return (x_new / w, y_new / w)

def correct_perspective_and_get_center(corners):
    """校正透视并计算校正后图像的中心点"""
    ordered_corners = order_corners(corners)

    width1 = distance(ordered_corners[0][0], ordered_corners[0][1],
                      ordered_corners[1][0], ordered_corners[1][1])
    width2 = distance(ordered_corners[2][0], ordered_corners[2][1],
                      ordered_corners[3][0], ordered_corners[3][1])
    avg_width = (width1 + width2) / 2

    height1 = distance(ordered_corners[1][0], ordered_corners[1][1],
                       ordered_corners[2][0], ordered_corners[2][1])
    height2 = distance(ordered_corners[3][0], ordered_corners[3][1],
                       ordered_corners[0][0], ordered_corners[0][1])
    avg_height = (height1 + height2) / 2

    if avg_width > avg_height:
        target_width = int(round(avg_width))
        target_height = int(round(avg_width / A4_RATIO))
    else:
        target_height = int(round(avg_height))
        target_width = int(round(avg_height * A4_RATIO))

    target_width = max(1, target_width)
    target_height = max(1, target_height)

    transform = calculate_perspective_transform(ordered_corners, target_width, target_height)
    corrected_center = (target_width / 2, target_height / 2)

    def matrix_inverse(m):
        a, b, c = m[0]
        d, e, f = m[1]
        g, h, i = m[2]

        det = a*(e*i - f*h) - b*(d*i - f*g) + c*(d*h - e*g)
        if abs(det) < 1e-8:
            return [[1, 0, 0], [0, 1, 0], [0, 0, 1]]

        adj = [
            [e*i - f*h, f*g - d*i, d*h - e*g],
            [c*h - b*i, a*i - c*g, b*g - a*h],
            [b*f - c*e, c*d - a*f, a*e - b*d]
        ]

        inv = [[x/det for x in row] for row in adj]
        return inv

    inv_transform = matrix_inverse(transform)
    original_center = apply_perspective_transform(corrected_center, inv_transform)

    center_x = max(0, min(int(round(original_center[0])), DETECT_WIDTH - 1))
    center_y = max(0, min(int(round(original_center[1])), DETECT_HEIGHT - 1))

    return center_x, center_y

def calculate_rotated_rect_properties(corners):
    """计算旋转矩形的属性（宽、高、角度、中心点）"""
    center_x = sum(p[0] for p in corners) / 4.0
    center_y = sum(p[1] for p in corners) / 4.0

    distances = []
    for i in range(4):
        x1, y1 = corners[i]
        x2, y2 = corners[(i+1)%4]
        dist = distance(x1, y1, x2, y2)
        distances.append(dist)

    sorted_dists = sorted(distances)
    width = (sorted_dists[0] + sorted_dists[1]) / 2.0
    height = (sorted_dists[2] + sorted_dists[3]) / 2.0

    max_dist_idx = distances.index(max(distances))
    x1, y1 = corners[max_dist_idx]
    x2, y2 = corners[(max_dist_idx+1)%4]
    angle = math.atan2(y2-y1, x2-x1) * 180.0 / math.pi

    return width, height, angle, (center_x, center_y)

def is_a4_rect(rect):
    """判断矩形是否符合A4纸比例，考虑倾斜情况"""
    corners = rect.corners()
    width, height, angle, center = calculate_rotated_rect_properties(corners)

    if min(width, height) < 1e-6:
        return False

    ratio = max(width, height) / min(width, height)
    angle_from_horizontal = abs(angle) % 90.0
    angle_ok = (angle_from_horizontal <= ANGLE_TOLERANCE) or \
               (abs(angle_from_horizontal - 90.0) <= ANGLE_TOLERANCE)

    return (A4_RATIO - RATIO_TOLERANCE) <= ratio <= (A4_RATIO + RATIO_TOLERANCE) and angle_ok

def is_valid_rectangle(rect, gray_img):
    """验证矩形是否符合要求"""
    x, y, w, h = rect.rect()

    # 计算宽高比
    aspect_ratio = float(w) / h

    # 检查宽高比是否在合理范围内
    if not (MIN_ASPECT_RATIO < aspect_ratio < MAX_ASPECT_RATIO):
        return False

    # 检查矩形面积是否在合理范围内
    area = w * h
    if area < MIN_RECT_AREA or area > MAX_RECT_AREA:
        return False

    # 计算矩形中心
    rect_center = (x + w//2, y + h//2)

    # 检查边框和中心亮度
    border_gray = gray_img.get_statistics(roi=(x, y, w, 5)).mean()
    center_gray = gray_img.get_statistics(roi=(rect_center[0]-2, rect_center[1]-2, 4, 4)).mean()

    if not (border_gray < BORDER_GRAY_THRESHOLD and center_gray > CENTER_GRAY_THRESHOLD):
        return False

    return True

def is_valid_circle(circle):
    """判断是否为有效的圆形（尺寸在合理范围内）"""
    x, y, r = circle.circle()
    area = math.pi * r * r
    return MIN_CIRCLE_AREA <= area <= MAX_CIRCLE_AREA

def detect_circles(img):
    """检测图像中的圆形并返回有效的圆心坐标列表"""
    valid_centers = []
    circles = img.find_circles(threshold=CIRCLE_THRESHOLD)

    if circles:
        for circle in circles:
            if is_valid_circle(circle):
                x, y, r = circle.circle()
                x_int = int(round(x))
                y_int = int(round(y))
                valid_centers.append((x_int, y_int))
                img.draw_circle((x_int, y_int, int(round(r))), color=(255, 0, 0), thickness=2)
                img.draw_cross(x_int, y_int, size=3, color=(0, 255, 255), thickness=2)

    return valid_centers

def camera_init():
    global sensor, uart
    try:
        sensor = Sensor(id = 2, width=DETECT_WIDTH, height=DETECT_HEIGHT)
        sensor.reset()
        sensor.set_vflip(False)
        sensor.set_framesize(width=DETECT_WIDTH, height=DETECT_HEIGHT)
        sensor.set_pixformat(Sensor.GRAYSCALE)
        Display.init(Display.VIRT, width=DETECT_WIDTH, height=DETECT_HEIGHT, fps=100, to_ide=True)
        MediaManager.init()

        print("正在初始化UART...")
        fpioa = FPIOA()
        fpioa.set_function(UART_TX_PIN, FPIOA.UART2_TXD)
        fpioa.set_function(UART_RX_PIN, FPIOA.UART2_RXD)

        uart = UART(UART_PORT, baudrate=UART_BAUDRATE)
        uart.init(
            baudrate=UART_BAUDRATE,
            bits=UART.EIGHTBITS,
            parity=UART.PARITY_NONE,
            stop=UART.STOPBITS_ONE
        )
        print(f"UART初始化完成，波特率: {UART_BAUDRATE}")

        sensor.run()
        print("相机初始化完成")
    except Exception as e:
        print(f"相机初始化失败: {e}")
        raise

def camera_deinit():
    global sensor, uart
    try:
        if sensor: sensor.stop()
        if uart: uart.deinit()
        Display.deinit()
        os.exitpoint(os.EXITPOINT_ENABLE_SLEEP)
        time.sleep_ms(100)
        MediaManager.deinit()
    except Exception as e:
        print(f"相机释放错误: {e}")

def send_uart_data(rect_center_x, rect_center_y):
    """通过UART发送数据（16进制格式）"""
    global uart, last_send_time

    current_time = time.ticks_ms()
    if current_time - last_send_time < 20:  # 50Hz控制
        return False

    if not uart:
        return False

    screen_center_x = DETECT_WIDTH // 2
    screen_center_y = DETECT_HEIGHT // 2
    distance_mm = 0
    physical_x = 0
    physical_y = 0

    sc_x = int(screen_center_x)
    sc_y = int(screen_center_y)
    rc_x = int(rect_center_x)
    rc_y = int(rect_center_y)
    dist = int(distance_mm)
    phy_x = int(physical_x * 10)
    phy_y = int(physical_y * 10)

    data = bytearray([
        HEADER,
        (sc_x >> 8) & 0xFF, sc_x & 0xFF,
        (sc_y >> 8) & 0xFF, sc_y & 0xFF,
        (rc_x >> 8) & 0xFF, rc_x & 0xFF,
        (rc_y >> 8) & 0xFF, rc_y & 0xFF,
        (dist >> 8) & 0xFF, dist & 0xFF,
        (phy_x >> 8) & 0xFF, phy_x & 0xFF,
        (phy_y >> 8) & 0xFF, phy_y & 0xFF,
        CHECKSUM,
        FOOTER
    ])

    try:
        uart.write(data)
        last_send_time = current_time
        print(f"[UART] 发送: {[hex(b) for b in data]}")
        print(f"屏幕中心: ({sc_x},{sc_y}) 矩形中心: ({rc_x},{rc_y})")
        print(f"距离: {distance_mm:.1f}mm 物理坐标: X={physical_x:.1f}mm Y={physical_y:.1f}mm")
        return True
    except Exception as e:
        print(f"串口发送失败: {e}")
        return False

def calculate_average_center(points):
    """计算多个点的平均坐标"""
    if not points:
        return None

    avg_x = sum(p[0] for p in points) / len(points)
    avg_y = sum(p[1] for p in points) / len(points)
    return (avg_x, avg_y)

def capture_picture():
    fps = time.clock()
    while True:
        fps.tick()
        try:
            os.exitpoint()
            global sensor
            img = sensor.snapshot()
            img.binary(gray_threshold, invert=False)

            # 存储所有检测到的中心点
            all_centers = []

            # 检测矩形框（优化后的逻辑）
            gray_img = img.copy()
            rects = gray_img.find_rects(threshold=RECT_DETECT_THRESHOLD)

            best_rect = None
            max_area = 0
            for r in rects:
                if is_valid_rectangle(r, gray_img):
                    area = r.rect()[2] * r.rect()[3]
                    if area > max_area:
                        max_area = area
                        best_rect = r

            if best_rect:
                corners = best_rect.corners()
                if is_a4_rect(best_rect):
                    width, height, angle, (center_x, center_y) = calculate_rotated_rect_properties(corners)
                    corrected_center_x, corrected_center_y = correct_perspective_and_get_center(corners)
                    all_centers.append((int(round(corrected_center_x)), int(round(corrected_center_y))))

                    img.draw_rectangle([int(v) for v in best_rect.rect()], color=(255, 0, 0))
                    for p in corners:
                        img.draw_circle(int(round(p[0])), int(round(p[1])), 5, color=(0, 255, 0))

                    cross_size = 3
                    img.draw_line(corrected_center_x - cross_size, corrected_center_y,
                                 corrected_center_x + cross_size, corrected_center_y,
                                 color=(255, 0, 0), thickness=2)
                    img.draw_line(corrected_center_x, corrected_center_y - cross_size,
                                 corrected_center_x, corrected_center_y + cross_size,
                                 color=(255, 0, 0), thickness=2)

                    print(f"A4纸矩形: 宽={width:.1f}, 高={height:.1f}, 角度={angle:.1f}°, 校正中心: ({corrected_center_x}, {corrected_center_y}), 面积: {max_area}")

            # 检测圆形
            circle_centers = detect_circles(img)
            all_centers.extend(circle_centers)
            print(f"检测到 {len(circle_centers)} 个有效圆形")

            # 计算并发送平均中心坐标
            if all_centers:
                avg_center = calculate_average_center(all_centers)
                if avg_center:
                    avg_x_int = int(round(avg_center[0]))
                    avg_y_int = int(round(avg_center[1]))

                    cross_size = 5
                    img.draw_line(avg_x_int - cross_size, avg_y_int,
                                 avg_x_int + cross_size, avg_y_int,
                                 color=(128, 0, 128), thickness=2)
                    img.draw_line(avg_x_int, avg_y_int - cross_size,
                                 avg_x_int, avg_y_int + cross_size,
                                 color=(128, 0, 128), thickness=2)

                    print(f"平均中心坐标: ({avg_x_int}, {avg_y_int})，基于 {len(all_centers)} 个点计算")
                    send_uart_data(avg_x_int, avg_y_int)
            else:
                print("未检测到任何形状")

            Display.show_image(img)
            img = None
            gc.collect()
            print(f"FPS: {fps.fps()}")
        except KeyboardInterrupt:
            print("用户停止")
            break
        except Exception as e:
            print(f"错误: {e}")
            break

def main():
    os.exitpoint(os.EXITPOINT_ENABLE)
    camera_is_init = False
    try:
        print("初始化相机（黑白模式）...")
        camera_init()
        camera_is_init = True
        print("开始捕获画面（带A4纸和圆形检测及坐标发送）...")
        capture_picture()
    except Exception as e:
        print(f"主程序错误: {e}")
    finally:
        if camera_is_init:
            print("释放相机资源...")
            camera_deinit()

if __name__ == "__main__":
    main()
