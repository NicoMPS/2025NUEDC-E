import time, os, gc, sys
import math
from media.sensor import *
from media.display import *
from media.media import *
from machine import UART, FPIOA, TOUCH

# ================ 系统配置 ================
DISPLAY_WIDTH = 800
DISPLAY_HEIGHT = 480
DETECT_WIDTH = 1920
DETECT_HEIGHT = 1080

# ================ A4纸物理尺寸(mm) ================
A4_WIDTH_MM = 210  # 短边
A4_HEIGHT_MM = 297  # 长边

# ================ 摄像头参数 ================
ACTUAL_FOCAL_LENGTH_MM = 3.6  # 实际焦距(mm)
SENSOR_WIDTH_MM = 4.8         # 传感器宽度(mm)
SENSOR_HEIGHT_MM = 3.6        # 传感器高度(mm)

# ================ 固定阈值配置 ================
THRESHOLD_VALUES = {
    "BLACK_GRAY_THRESHOLD": 149,  # 边框黑度阈值
    "CENTER_GRAY_THRESHOLD": 130, # 中心亮度阈值
    "RECT_DETECT_THRESHOLD": 2500 # 矩形检测灵敏度
}

# ================ 矩形宽高比限制 ================
MIN_ASPECT_RATIO = 1.35
MAX_ASPECT_RATIO = 2.0

# ================ 串口配置 ================
UART_PORT = 2
UART_BAUDRATE = 115200
UART_TX_PIN = 11
UART_RX_PIN = 12
HEADER = 0x55
CHECKSUM = 0x77
FOOTER = 0x44

# ================ 全局变量 ================
#sensor = None
#uart = None
#running = True
#img_okcount = 0
# ================ 全局变量 ================
sensor = None
uart = None
running = True
img_okcount = 0
no_detect_count = 0  # 新增：连续未检测到目标的计数器
MAX_NO_DETECT_COUNT = 4  # 新增：最大允许连续未检测到目标的次数
last_valid_data = None  # 存储格式：{'screen_center':(), 'rect_center':(), ... , 'valid_count':10}



def camera_init():
    global sensor, uart
    try:
        print("正在初始化相机...")
        sensor = Sensor(width=DETECT_WIDTH, height=DETECT_HEIGHT)
        sensor.reset()
        sensor.set_framesize(width=DETECT_WIDTH, height=DETECT_HEIGHT)
        sensor.set_pixformat(Sensor.RGB565)

        # 初始化串口
        print("正在初始化UART2...")
        fpioa = FPIOA()
        fpioa.set_function(UART_TX_PIN, FPIOA.UART2_TXD)
        fpioa.set_function(UART_RX_PIN, FPIOA.UART2_RXD)

        uart = UART(UART_PORT, baudrate=UART_BAUDRATE)
        uart.init(
            baudrate=UART_BAUDRATE,
            bits=UART.EIGHTBITS,
            parity=UART.PARITY_NONE,
            stop=UART.STOPBITS_ONE
        )
        print(f"UART2初始化完成，波特率: {UART_BAUDRATE}")

        # 初始化显示
        Display.init(Display.ST7701, width=DISPLAY_WIDTH, height=DISPLAY_HEIGHT, fps=30)
        MediaManager.init()
        sensor.run()
        print("相机初始化完成")
    except Exception as e:
        print(f"相机初始化失败: {e}")
        raise

def camera_deinit():
    global sensor, uart
    try:
        if sensor: sensor.stop()
        if uart: uart.deinit()
        Display.deinit()
        MediaManager.deinit()
    except Exception as e:
        print(f"相机释放错误: {e}")

def calculate_distance_and_position(rect, img_width, img_height):
    """
    计算距离和物理位置(优化版)
    参数:
        rect: 检测到的矩形 (x,y,w,h)
        img_width: 图像宽度(像素)
        img_height: 图像高度(像素)
    返回:
        (distance_mm, center_x_mm, center_y_mm)
    """
    x, y, w, h = rect

    # 计算焦距像素值(基于传感器物理尺寸和图像分辨率)
    focal_length_px = (ACTUAL_FOCAL_LENGTH_MM / SENSOR_WIDTH_MM) * DETECT_WIDTH

    # 使用A4纸长边和短边分别计算距离，取平均值
    distance_mm_width = (A4_WIDTH_MM * focal_length_px) / w
    distance_mm_height = (A4_HEIGHT_MM * focal_length_px) / h
    distance_mm = (distance_mm_width + distance_mm_height) / 2
    distance_mm = max(500, min(1600, distance_mm))  # 限制在500-1600mm范围内

    # 计算物理坐标(mm)
    center_x_px = x + w/2 - img_width/2
    center_y_px = y + h/2 - img_height/2
    center_x_mm = (center_x_px * A4_WIDTH_MM) / w
    center_y_mm = (center_y_px * A4_HEIGHT_MM) / h

    return distance_mm, center_x_mm, center_y_mm

#def send_uart_data(screen_center, rect_center, distance_mm, physical_x, physical_y):
#    """通过UART2发送数据（16进制格式）"""
#    global uart

#    if not uart:
#        return False

#    # 将坐标转换为整数（像素坐标）
#    sc_x = int(screen_center[0])
#    sc_y = int(screen_center[1])
#    rc_x = int(rect_center[0])
#    rc_y = int(rect_center[1])
#    dist = int(distance_mm)
#    phy_x = int(physical_x * 10)  # 放大10倍保持精度
#    phy_y = int(physical_y * 10)

#    # 16进制数据包格式：
#    # 包头(1B) + 屏幕中心XY(各2B) + 矩形中心XY(各2B) + 距离(2B) + 物理坐标XY(各2B) + 校验和(1B) + 包尾(1B)
#    data = bytearray([
#        HEADER,
#        #(sc_x >> 8) & 0xFF, sc_x & 0xFF,  # 屏幕中心X
#        #(sc_y >> 8) & 0xFF, sc_y & 0xFF,  # 屏幕中心Y
#        (rc_x >> 8) & 0xFF, rc_x & 0xFF,  # 矩形中心X
#        (rc_y >> 8) & 0xFF, rc_y & 0xFF,  # 矩形中心Y
#        (dist >> 8) & 0xFF, dist & 0xFF,   # 距离(mm)
#        (phy_x >> 8) & 0xFF, phy_x & 0xFF, # 物理X坐标(x10)
#        (phy_y >> 8) & 0xFF, phy_y & 0xFF, # 物理Y坐标(x10)
#        CHECKSUM,
#        FOOTER
#    ])

#    try:
#        uart.write(data)
#        print(f"[UART] 发送: {[hex(b) for b in data]}")
#        print(f"屏幕中心: ({sc_x},{sc_y}) 矩形中心: ({rc_x},{rc_y})")
#        print(f"距离: {distance_mm:.1f}mm 物理坐标: X={physical_x:.1f}mm Y={physical_y:.1f}mm")
#        return True
#    except Exception as e:
#        print(f"串口发送失败: {e}")
#        return False

#def send_uart_data(screen_center, rect_center, distance_mm, physical_x, physical_y, is_valid=True):
#    """通过UART2发送数据（16进制格式）
#    参数:
#        is_valid: 是否检测到有效目标
#    """
#    global uart, no_detect_count

#    if not uart:
#        return False

#    # 处理无效数据（连续多次未检测到目标）
#    if not is_valid:
#        no_detect_count += 1
#        if no_detect_count < MAX_NO_DETECT_COUNT:
#            return False  # 未达到最大未检测次数，不发送数据
#        # 发送全0数据
#        rc_x = 0
#        rc_y = 0
#        dist = 0
#        phy_x = 0
#        phy_y = 0
#    else:
#        # 有效数据
#        no_detect_count = 0  # 重置计数器
#        # 将坐标转换为整数（像素坐标）
#        rc_x = int(rect_center[0])
#        rc_y = int(rect_center[1])
#        dist = int(distance_mm)
#        phy_x = int(physical_x * 10)  # 放大10倍保持精度
#        phy_y = int(physical_y * 10)

#    # 16进制数据包格式：
#    # 包头(1B) + 矩形中心XY(各2B) + 距离(2B) + 物理坐标XY(各2B) + 校验和(1B) + 包尾(1B)
#    data = bytearray([
#        HEADER,
#        (rc_x >> 8) & 0xFF, rc_x & 0xFF,  # 矩形中心X
#        (rc_y >> 8) & 0xFF, rc_y & 0xFF,  # 矩形中心Y
#        (dist >> 8) & 0xFF, dist & 0xFF,   # 距离(mm)
#        (phy_x >> 8) & 0xFF, phy_x & 0xFF, # 物理X坐标(x10)
#        (phy_y >> 8) & 0xFF, phy_y & 0xFF, # 物理Y坐标(x10)
#        CHECKSUM,
#        FOOTER
#    ])

#    try:
#        uart.write(data)
#        if is_valid:
#            print(f"[UART] 发送有效数据: {[hex(b) for b in data]}")
#            print(f"矩形中心: ({rc_x},{rc_y})")
##            print(f"距离: {distance_mm:.1f}mm 物理坐标: X={physical_x:.1f}mm Y={physical_y:.1f}mm")
#        else:
#            print("[UART] 连续未检测到目标，发送全0数据")
#        return True
#    except Exception as e:
#        print(f"串口发送失败: {e}")
#        return Fals

def send_uart_data(screen_center, rect_center, distance_mm, physical_x, physical_y, is_valid=True):
    """通过UART2发送数据（16进制格式）
    新增功能：连续10帧发送最后一次有效坐标后再发全0
    """
    global uart, no_detect_count, last_valid_data

    if not uart:
        return False

    # 记录最后一次有效数据
    if is_valid:
        last_valid_data = {
            "screen_center": screen_center,
            "rect_center": rect_center,
            "distance_mm": distance_mm,
            "physical_x": physical_x,
            "physical_y": physical_y,
            "valid_count": 10  # 重置有效帧计数器
        }
    elif hasattr(last_valid_data, 'valid_count') and last_valid_data['valid_count'] > 0:
        # 使用缓存的最后一次有效数据
        last_valid_data['valid_count'] -= 1
        screen_center = last_valid_data['screen_center']
        rect_center = last_valid_data['rect_center']
        distance_mm = last_valid_data['distance_mm']
        physical_x = last_valid_data['physical_x']
        physical_y = last_valid_data['physical_y']
        is_valid = True  # 标记为有效数据发送
    else:
        # 发送全0数据
        no_detect_count += 1
        if no_detect_count < MAX_NO_DETECT_COUNT:
            return False
        rc_x = 0
        rc_y = 0
        dist = 0
        phy_x = 0
        phy_y = 0

    # 有效数据处理
    if is_valid:
        no_detect_count = 0
        rc_x = int(rect_center[0])
        rc_y = int(rect_center[1])
        dist = int(distance_mm)
        phy_x = int(physical_x * 10)
        phy_y = int(physical_y * 10)

    # 16进制数据包格式
    data = bytearray([
        HEADER,
        (rc_x >> 8) & 0xFF, rc_x & 0xFF,
        (rc_y >> 8) & 0xFF, rc_y & 0xFF,
        (dist >> 8) & 0xFF, dist & 0xFF,
        (phy_x >> 8) & 0xFF, phy_x & 0xFF,
        (phy_y >> 8) & 0xFF, phy_y & 0xFF,
        CHECKSUM,
        FOOTER
    ])

    try:
        uart.write(data)
        if is_valid:
            if last_valid_data['valid_count'] < 10:  # 使用缓存数据时
                print(f"[UART] 使用缓存数据({10 - last_valid_data['valid_count']}/10): {[hex(b) for b in data]}")
            else:
                print(f"[UART] 发送实时数据: {[hex(b) for b in data]}")
        else:
            print("[UART] 目标丢失，发送全0数据")
        return True
    except Exception as e:
        print(f"串口发送失败: {e}")
        return False

# 在全局变量部分新增
last_valid_data = None  # 新增：存储最后一次有效数据



#def detect_outer_rectangle(img):
#    """检测外接矩形并计算坐标(优化版)"""
#    global img_okcount

#    try:
#        if img is None:
#            print("错误: 输入图像为空")
#            return False

#        img_width = img.width()
#        img_height = img.height()
#        screen_center = (img_width // 2, img_height // 2)  # 屏幕中心坐标

#        gray = img.to_grayscale()
#        counts = gray.find_rects(threshold=THRESHOLD_VALUES["RECT_DETECT_THRESHOLD"])

#        best_rect = None
#        max_area = 0
#        min_area_threshold = img_width * img_height * 0.03  # 设置最小面积阈值为图像总面积的5%

#        for r in counts:
#            x, y, w, h = r.rect()
#            area = w * h
#            aspect_ratio = float(w) / h

#            # 添加面积过滤条件
#            if (MIN_ASPECT_RATIO < aspect_ratio < MAX_ASPECT_RATIO and
#                area > max_area and
#                area > min_area_threshold):
#                max_area = area
#                best_rect = r

#        if best_rect:
#            x1, y1 = best_rect.rect()[0], best_rect.rect()[1]
#            x2, y2 = x1 + best_rect.rect()[2], y1 + best_rect.rect()[3]
#            rect_center = ((x1 + x2) // 2, (y1 + y2) // 2)  # 矩形中心坐标

#            # 验证矩形有效性
#            border_gray = gray.get_statistics(roi=(x1, y1, best_rect.rect()[2], 5)).mean()
#            center_gray = gray.get_statistics(roi=(rect_center[0], rect_center[1], 4, 4)).mean()

#            if (border_gray < THRESHOLD_VALUES["BLACK_GRAY_THRESHOLD"] and
#                center_gray > THRESHOLD_VALUES["CENTER_GRAY_THRESHOLD"]):

#                img_okcount += 1
#                distance_mm, physical_x, physical_y = calculate_distance_and_position(
#                    best_rect.rect(), img_width, img_height)

#                # 绘制图形元素
#                img.draw_rectangle(best_rect.rect(), color=(255, 0, 0), thickness=2)
#                img.draw_circle(rect_center[0], rect_center[1], 5, color=(255, 0, 0), fill=True)
#                img.draw_line(screen_center[0], screen_center[1],
#                            rect_center[0], rect_center[1],
#                            color=(0, 255, 0), thickness=2)
#                img.draw_circle(screen_center[0], screen_center[1], 5, color=(0, 0, 255), fill=True)

#                # 显示调试信息
#                img.draw_string(10, 10, f"检测成功: {img_okcount}", color=(255,255,255), scale=2)
#                img.draw_string(10, 40, f"距离: {distance_mm:.1f}mm", color=(255,255,255), scale=1.5)
#                img.draw_string(10, 70, f"物理坐标: X={physical_x:.1f}mm Y={physical_y:.1f}mm",
#                              color=(255,255,255), scale=1.2)
#                img.draw_string(10, 100, f"宽高比: {float(best_rect.rect()[2])/best_rect.rect()[3]:.2f}",
#                              color=(255,255,255), scale=1.2)

#                # 发送串口数据
#                send_uart_data(screen_center, rect_center, distance_mm, physical_x, physical_y)
#                return True

#        img.draw_string(20, 20, "未检测到目标", color=(255,0,0), scale=3)
#        return False
#    except Exception as e:
#        print(f"检测错误: {e}")
#        return False

#def detect_outer_rectangle(img):
#    """检测外接矩形并计算坐标(优化版)"""
#    global img_okcount, no_detect_count

#    try:
#        if img is None:
#            print("错误: 输入图像为空")
#            return False

#        img_width = img.width()
#        img_height = img.height()
#        screen_center = (img_width // 2, img_height // 2)  # 屏幕中心坐标

#        gray = img.to_grayscale()
#        counts = gray.find_rects(threshold=THRESHOLD_VALUES["RECT_DETECT_THRESHOLD"])

#        best_rect = None
#        max_area = 0
#        min_area_threshold = img_width * img_height * 0.0032  # 设置最小面积阈值为图像总面积的3%

#        for r in counts:
#            x, y, w, h = r.rect()
#            area = w * h
#            aspect_ratio = float(w) / h

#            # 添加面积过滤条件
#            if (MIN_ASPECT_RATIO < aspect_ratio < MAX_ASPECT_RATIO and
#                area > max_area and
#                area > min_area_threshold):
#                max_area = area
#                best_rect = r

#        if best_rect:
#            x1, y1 = best_rect.rect()[0], best_rect.rect()[1]
#            x2, y2 = x1 + best_rect.rect()[2], y1 + best_rect.rect()[3]
#            rect_center = ((x1 + x2) // 2, (y1 + y2) // 2)  # 矩形中心坐标

#            # 验证矩形有效性
#            border_gray = gray.get_statistics(roi=(x1, y1, best_rect.rect()[2], 5)).mean()
#            center_gray = gray.get_statistics(roi=(rect_center[0], rect_center[1], 4, 4)).mean()

#            if (border_gray < THRESHOLD_VALUES["BLACK_GRAY_THRESHOLD"] and
#                center_gray > THRESHOLD_VALUES["CENTER_GRAY_THRESHOLD"]):

#                img_okcount += 1
#                distance_mm, physical_x, physical_y = calculate_distance_and_position(
#                    best_rect.rect(), img_width, img_height)

#                # 绘制图形元素
#                img.draw_rectangle(best_rect.rect(), color=(255, 0, 0), thickness=2)
#                img.draw_circle(rect_center[0], rect_center[1], 5, color=(255, 0, 0), fill=True)
#                img.draw_line(screen_center[0], screen_center[1],
#                            rect_center[0], rect_center[1],
#                            color=(0, 255, 0), thickness=2)
#                img.draw_circle(screen_center[0], screen_center[1], 5, color=(0, 0, 255), fill=True)

#                # 显示调试信息
#                img.draw_string(10, 10, f"检测成功: {img_okcount}", color=(255,255,255), scale=2)
#                img.draw_string(10, 40, f"距离: {distance_mm:.1f}mm", color=(255,255,255), scale=1.5)
#                img.draw_string(10, 70, f"物理坐标: X={physical_x:.1f}mm Y={physical_y:.1f}mm",
#                              color=(255,255,255), scale=1.2)
#                img.draw_string(10, 100, f"宽高比: {float(best_rect.rect()[2])/best_rect.rect()[3]:.2f}",
#                              color=(255,255,255), scale=1.2)

#                # 发送串口数据
#                send_uart_data(screen_center, rect_center, distance_mm, physical_x, physical_y, is_valid=True)
#                return True

#        # 未检测到有效目标
#        img.draw_string(20, 20, "未检测到目标", color=(255,0,0), scale=3)
#        send_uart_data((0,0), (0,0), 0, 0, 0, is_valid=False)
#        return False
#    except Exception as e:
#        print(f"检测错误: {e}")
#        send_uart_data((0,0), (0,0), 0, 0, 0, is_valid=False)
#        return False
#def detect_outer_rectangle(img):
#    """增强版矩形检测：优化近距离识别，不改变原有架构"""
#    global img_okcount, no_detect_count

#    try:
#        if img is None:
#            print("错误: 输入图像为空")
#            send_uart_data((0,0), (0,0), 0, 0, 0, is_valid=False)
#            return False

#        img_width = img.width()
#        img_height = img.height()
#        screen_center = (img_width // 2, img_height // 2)

#        # 图像预处理（保持原有逻辑）
#        gray = img.to_grayscale()
#        counts = gray.find_rects(threshold=THRESHOLD_VALUES["RECT_DETECT_THRESHOLD"])

#        best_rect = None
#        max_score = 0  # 改用评分机制
#        min_area_threshold = img_width * img_height * 0.0032  # 降低面积阈值

#        # ========== 核心改进部分 ==========
#        for r in counts:
#            x, y, w, h = r.rect()
#            area = w * h
#            aspect_ratio = float(w) / h

#            # 动态宽高比限制（近距离放宽条件）
#            is_large_area = area > img_width * img_height * 0.005  # 面积超过5%判定为近距离
#            aspect_low = MIN_ASPECT_RATIO * (0.6 if is_large_area else 1.0)  # 近距离放宽15%
#            aspect_high = MAX_ASPECT_RATIO * (1.5 if is_large_area else 1.0)

#            # 综合评分 = 面积 * 宽高比适配度 * 距离补偿系数
#            aspect_score = min(aspect_ratio/aspect_low, aspect_high/aspect_ratio)
#            score = area * aspect_score * (1.3 if is_large_area else 1.0)  # 近距离加权

#            if (aspect_low < aspect_ratio < aspect_high and
#                score > max_score and
#                area > min_area_threshold):

#                max_score = score
#                best_rect = r
#        # ========== 结束改进部分 ==========

#        if best_rect:
#            x, y, w, h = best_rect.rect()
#            rect_center = (x + w//2, y + h//2)

#            # 有效性验证（原逻辑不变）
#            border_gray = gray.get_statistics(roi=(x, y, w, 5)).mean()
#            center_gray = gray.get_statistics(roi=(rect_center[0]-2, rect_center[1]-2, 4, 4)).mean()

#            if (border_gray < THRESHOLD_VALUES["BLACK_GRAY_THRESHOLD"] and
#                center_gray > THRESHOLD_VALUES["CENTER_GRAY_THRESHOLD"]):

#                img_okcount += 1
#                distance_mm, physical_x, physical_y = calculate_distance_and_position(
#                    (x, y, w, h), img_width, img_height)

#                # 绘制图形（近距离用橙色标记）
#                color = (255, 165, 0) if distance_mm < 800 else (255, 0, 0)
#                img.draw_rectangle((x, y, w, h), color=color, thickness=2)
#                img.draw_circle(rect_center[0], rect_center[1], 5, color=color, fill=True)
#                img.draw_line(screen_center[0], screen_center[1],
#                            rect_center[0], rect_center[1],
#                            color=(0, 255, 0), thickness=2)

#                # 显示调试信息（新增近距离标记）
#                img.draw_string(10, 10, f"检测成功: {img_okcount}", color=(255,255,255), scale=2)
#                img.draw_string(10, 40, f"距离: {distance_mm:.1f}mm", color=(255,255,255), scale=1.5)
#                img.draw_string(10, 70, f"坐标: X={physical_x:.1f}mm Y={physical_y:.1f}mm",
#                              color=(255,255,255), scale=1.2)
#                img.draw_string(10, 100, f"模式: {'近距' if distance_mm < 800 else '远距'}",
#                              color=(255,165,0) if distance_mm < 800 else (255,255,255), scale=1.2)

#                # 发送串口数据（原逻辑不变）
#                send_uart_data(screen_center, rect_center, distance_mm, physical_x, physical_y, is_valid=True)
#                return True

#        # 未检测到有效目标
#        img.draw_string(20, 20, "未检测到目标", color=(255,0,0), scale=3)
#        send_uart_data((0,0), (0,0), 0, 0, 0, is_valid=False)
#        return False
#    except Exception as e:
#        print(f"检测错误: {e}")
#        send_uart_data((0,0), (0,0), 0, 0, 0, is_valid=False)
#        return False






def detect_outer_rectangle(img):
    """增强版矩形检测：优化贴脸红色圆环识别"""
    global img_okcount, no_detect_count, last_valid_data

    try:
        if img is None:
            print("错误: 输入图像为空")
            send_uart_data((0,0), (0,0), 0, 0, 0, is_valid=False)
            return False

        img_width = img.width()
        img_height = img.height()
        screen_center = (img_width // 2, img_height // 2)

        gray = img.to_grayscale()
        counts = gray.find_rects(threshold=THRESHOLD_VALUES["RECT_DETECT_THRESHOLD"])

        best_rect = None
        max_score = 0
        min_area_threshold = img_width * img_height * 0.003

        # ===== 矩形检测主逻辑 =====
        for r in counts:
            x, y, w, h = r.rect()
            area = w * h
            aspect_ratio = float(w) / h

            # 动态宽高比调整（近距离放宽限制）
            is_near = area > img_width * img_height * 0.1  # 面积超过10%判定为极近距离
            aspect_low = MIN_ASPECT_RATIO * (0.6 if is_near else 1.0)
            aspect_high = MAX_ASPECT_RATIO * (1.5 if is_near else 1.0)

            # 综合评分 = 面积 * 宽高比适配度 * 距离补偿
            aspect_score = min(aspect_ratio/aspect_low, aspect_high/aspect_ratio)
            score = area * aspect_score * (1.5 if is_near else 1.0)

            if (aspect_low < aspect_ratio < aspect_high and
                score > max_score and
                area > min_area_threshold):
                max_score = score
                best_rect = r

        # ===== 增强版圆形检测（仅极近距离触发） =====
        circle_info = None
        if best_rect and (best_rect.rect()[2] * best_rect.rect()[3] > img_width * img_height * 0.15):
            x, y, w, h = best_rect.rect()

            # 动态参数计算
            r_min = max(5, int(min(w,h) * 0.15))  # 半径下限为短边的15%
            r_max = min(30, int(max(w,h) * 0.25)) # 半径上限为长边的25%

            # 中心区域ROI（缩小检测范围）
            roi_width = int(w * 0.6)
            roi_height = int(h * 0.6)
            roi = (
                x + w//2 - roi_width//2,
                y + h//2 - roi_height//2,
                roi_width,
                roi_height
            )

            # 高灵敏度圆形检测
            circles = gray.find_circles(
                roi=roi,
                threshold=3500,  # 比矩形更高的灵敏度
                r_min=r_min,
                r_max=r_max,
                edge_ratio=0.7,
                step=2  # 精细检测
            )

            if circles:
                # 选择最接近中心的圆
                img_center = (x + w//2, y + h//2)
                circles.sort(key=lambda c: math.dist((c.x(), c.y()), img_center))
                best_circle = circles[0]
                circle_info = {
                    'center': (best_circle.x(), best_circle.y()),
                    'radius': best_circle.r()
                }

                # 增强绘制（红色圆环+中心点）
                img.draw_circle(circle_info['center'][0], circle_info['center'][1],
                               circle_info['radius'], color=(255,0,0), thickness=2)
                img.draw_circle(circle_info['center'][0], circle_info['center'][1],
                               max(3, circle_info['radius']-4), color=(255,0,0), thickness=1)
                img.draw_circle(circle_info['center'][0], circle_info['center'][1],
                               5, color=(255,255,0), fill=True)

        # ===== 结果处理 =====
        if best_rect:
            x, y, w, h = best_rect.rect()
            rect_center = circle_info['center'] if circle_info else (x + w//2, y + h//2)

            # 验证有效性（原逻辑不变）
            border_gray = gray.get_statistics(roi=(x, y, w, 5)).mean()
            center_gray = gray.get_statistics(roi=(rect_center[0]-2, rect_center[1]-2, 4, 4)).mean()

            if (border_gray < THRESHOLD_VALUES["BLACK_GRAY_THRESHOLD"] and
                center_gray > THRESHOLD_VALUES["CENTER_GRAY_THRESHOLD"]):

                img_okcount += 1
                distance_mm, physical_x, physical_y = calculate_distance_and_position(
                    (x, y, w, h), img_width, img_height)

                # 绘制图形元素（保持红色主题）
                color = (255, 0, 0)
                img.draw_rectangle((x, y, w, h), color=color, thickness=2)
                if not circle_info:  # 非圆形模式时绘制默认中心点
                    img.draw_circle(rect_center[0], rect_center[1], 5, color=color, fill=True)
                img.draw_line(screen_center[0], screen_center[1],
                            rect_center[0], rect_center[1],
                            color=(0, 255, 0), thickness=2)

                # 显示调试信息
                img.draw_string(10, 10, f"检测成功: {img_okcount}", color=(255,255,255), scale=2)
                img.draw_string(10, 40, f"距离: {distance_mm:.1f}mm", color=(255,255,255), scale=1.5)
                mode = "极近(圆)" if circle_info else "近距" if distance_mm < 800 else "远距"
                img.draw_string(10, 70, f"模式: {mode}", color=(255,0,0), scale=1.5)
                if circle_info:
                    img.draw_string(10, 100, f"圆半径: {circle_info['radius']}px",
                                  color=(255,255,0), scale=1.2)

                send_uart_data(screen_center, rect_center, distance_mm, physical_x, physical_y, is_valid=True)
                return True

        # 未检测到有效目标
        img.draw_string(20, 20, "未检测到目标", color=(255,0,0), scale=3)
        send_uart_data((0,0), (0,0), 0, 0, 0, is_valid=False)
        return False

    except Exception as e:
        print(f"检测错误: {e}")
        send_uart_data((0,0), (0,0), 0, 0, 0, is_valid=False)
        return False

def main_loop():
    fps = time.clock()
    while running:
        try:
            fps.tick()
            os.exitpoint()

            img = sensor.snapshot()
            img = img.mean_pool(5,5)
            img = img.copy(roi=[77,36,240,144])


            if detect_outer_rectangle(img):
                img.draw_string(20, 20, "检测成功!", color=(0, 255, 0), scale=3)
            else:
                img.draw_string(20, 20, "未检测到目标", color=(255, 0, 0), scale=3)

            # 显示固定阈值信息
            #img.draw_string(20, 60, f"边框阈值: {THRESHOLD_VALUES['BLACK_GRAY_THRESHOLD']}",
            #              color=(255, 255, 255), scale=2)
            #img.draw_string(20, 100, f"中心阈值: {THRESHOLD_VALUES['CENTER_GRAY_THRESHOLD']}",
            #             color=(255, 255, 255), scale=2)
            #img.draw_string(20, 140, f"检测灵敏度: {THRESHOLD_VALUES['RECT_DETECT_THRESHOLD']}",
            #              color=(255, 255, 255), scale=2)

            # 显示帧率
            img.draw_string(DISPLAY_WIDTH-150, DISPLAY_HEIGHT-40,
                          f"FPS: {fps.fps():.1f}", color=(255,255,255), scale=2)

            Display.show_image(img)
            gc.collect()

        except KeyboardInterrupt:
            global running
            running = False
        except Exception as e:
            print(f"主循环错误: {e}")
            time.sleep(0.5)

def main():
    os.exitpoint(os.EXITPOINT_ENABLE)
    try:
        camera_init()
        main_loop()
    except Exception as e:
        print(f"主程序错误: {e}")
    finally:
        camera_deinit()
        print("程序结束")

if __name__ == "__main__":
    main()
