import time, os, gc, sys
import math
from media.sensor import *
from media.display import *
from media.media import *
from machine import UART, FPIOA, TOUCH

# ================ 系统配置 ================
DISPLAY_WIDTH = 800
DISPLAY_HEIGHT = 480
DETECT_WIDTH = ALIGN_UP(240, 16)
DETECT_HEIGHT = ALIGN_UP(144,16)

# ================ A4纸物理尺寸(mm) ================
A4_WIDTH_MM = 210  # 短边
A4_HEIGHT_MM = 297  # 长边

# ================ 摄像头参数 ================
ACTUAL_FOCAL_LENGTH_MM = 3.6  # 实际焦距(mm)
SENSOR_WIDTH_MM = 4.8         # 传感器宽度(mm)
SENSOR_HEIGHT_MM = 3.6        # 传感器高度(mm)

# ================ 固定阈值配置 ================
THRESHOLD_VALUES = {
    "BLACK_GRAY_THRESHOLD": 149,  # 边框黑度阈值
    "CENTER_GRAY_THRESHOLD": 130, # 中心亮度阈值
    "RECT_DETECT_THRESHOLD": 2500 # 矩形检测灵敏度
}

# ================ 矩形宽高比限制 ================
MIN_ASPECT_RATIO = 1.35
MAX_ASPECT_RATIO = 2.0

# ================ 串口配置 ================
UART_PORT = 2
UART_BAUDRATE = 115200
UART_TX_PIN = 11
UART_RX_PIN = 12
HEADER = 0x55
CHECKSUM = 0x77
FOOTER = 0x44

# ================ 全局变量 ================
#sensor = None
#uart = None
#running = True
#img_okcount = 0
# ================ 全局变量 ================
sensor = None
uart = None
running = True
img_okcount = 0
no_detect_count = 0  # 新增：连续未检测到目标的计数器
MAX_NO_DETECT_COUNT = 4  # 新增：最大允许连续未检测到目标的次数




def camera_init():
    global sensor, uart
    try:
        print("正在初始化相机...")
        sensor = Sensor(width=DETECT_WIDTH, height=DETECT_HEIGHT)
        sensor.reset()
        sensor.set_framesize(width=DETECT_WIDTH, height=DETECT_HEIGHT)
        sensor.set_pixformat(Sensor.RGB565)

        # 初始化串口
        print("正在初始化UART2...")
        fpioa = FPIOA()
        fpioa.set_function(UART_TX_PIN, FPIOA.UART2_TXD)
        fpioa.set_function(UART_RX_PIN, FPIOA.UART2_RXD)

        uart = UART(UART_PORT, baudrate=UART_BAUDRATE)
        uart.init(
            baudrate=UART_BAUDRATE,
            bits=UART.EIGHTBITS,
            parity=UART.PARITY_NONE,
            stop=UART.STOPBITS_ONE
        )
        print(f"UART2初始化完成，波特率: {UART_BAUDRATE}")

        # 初始化显示
        Display.init(Display.ST7701, width=DISPLAY_WIDTH, height=DISPLAY_HEIGHT, fps=30)
        MediaManager.init()
        sensor.run()
        print("相机初始化完成")
    except Exception as e:
        print(f"相机初始化失败: {e}")
        raise

def camera_deinit():
    global sensor, uart
    try:
        if sensor: sensor.stop()
        if uart: uart.deinit()
        Display.deinit()
        MediaManager.deinit()
    except Exception as e:
        print(f"相机释放错误: {e}")

def calculate_distance_and_position(rect, img_width, img_height):
    """
    计算距离和物理位置(优化版)
    参数:
        rect: 检测到的矩形 (x,y,w,h)
        img_width: 图像宽度(像素)
        img_height: 图像高度(像素)
    返回:
        (distance_mm, center_x_mm, center_y_mm)
    """
    x, y, w, h = rect

    # 计算焦距像素值(基于传感器物理尺寸和图像分辨率)
    focal_length_px = (ACTUAL_FOCAL_LENGTH_MM / SENSOR_WIDTH_MM) * DETECT_WIDTH

    # 使用A4纸长边和短边分别计算距离，取平均值
    distance_mm_width = (A4_WIDTH_MM * focal_length_px) / w
    distance_mm_height = (A4_HEIGHT_MM * focal_length_px) / h
    distance_mm = (distance_mm_width + distance_mm_height) / 2
    distance_mm = max(500, min(1600, distance_mm))  # 限制在500-1600mm范围内

    # 计算物理坐标(mm)
    center_x_px = x + w/2 - img_width/2
    center_y_px = y + h/2 - img_height/2
    center_x_mm = (center_x_px * A4_WIDTH_MM) / w
    center_y_mm = (center_y_px * A4_HEIGHT_MM) / h

    return distance_mm, center_x_mm, center_y_mm

#def send_uart_data(screen_center, rect_center, distance_mm, physical_x, physical_y):
#    """通过UART2发送数据（16进制格式）"""
#    global uart

#    if not uart:
#        return False

#    # 将坐标转换为整数（像素坐标）
#    sc_x = int(screen_center[0])
#    sc_y = int(screen_center[1])
#    rc_x = int(rect_center[0])
#    rc_y = int(rect_center[1])
#    dist = int(distance_mm)
#    phy_x = int(physical_x * 10)  # 放大10倍保持精度
#    phy_y = int(physical_y * 10)

#    # 16进制数据包格式：
#    # 包头(1B) + 屏幕中心XY(各2B) + 矩形中心XY(各2B) + 距离(2B) + 物理坐标XY(各2B) + 校验和(1B) + 包尾(1B)
#    data = bytearray([
#        HEADER,
#        #(sc_x >> 8) & 0xFF, sc_x & 0xFF,  # 屏幕中心X
#        #(sc_y >> 8) & 0xFF, sc_y & 0xFF,  # 屏幕中心Y
#        (rc_x >> 8) & 0xFF, rc_x & 0xFF,  # 矩形中心X
#        (rc_y >> 8) & 0xFF, rc_y & 0xFF,  # 矩形中心Y
#        (dist >> 8) & 0xFF, dist & 0xFF,   # 距离(mm)
#        (phy_x >> 8) & 0xFF, phy_x & 0xFF, # 物理X坐标(x10)
#        (phy_y >> 8) & 0xFF, phy_y & 0xFF, # 物理Y坐标(x10)
#        CHECKSUM,
#        FOOTER
#    ])

#    try:
#        uart.write(data)
#        print(f"[UART] 发送: {[hex(b) for b in data]}")
#        print(f"屏幕中心: ({sc_x},{sc_y}) 矩形中心: ({rc_x},{rc_y})")
#        print(f"距离: {distance_mm:.1f}mm 物理坐标: X={physical_x:.1f}mm Y={physical_y:.1f}mm")
#        return True
#    except Exception as e:
#        print(f"串口发送失败: {e}")
#        return False

def send_uart_data(screen_center, rect_center, distance_mm, physical_x, physical_y, is_valid=True):
    """通过UART2发送数据（16进制格式）
    参数:
        is_valid: 是否检测到有效目标
    """
    global uart, no_detect_count

    if not uart:
        return False

    # 处理无效数据（连续多次未检测到目标）
    if not is_valid:
        no_detect_count += 1
        if no_detect_count < MAX_NO_DETECT_COUNT:
            return False  # 未达到最大未检测次数，不发送数据
        # 发送全0数据
        rc_x = 0
        rc_y = 0
        dist = 0
        phy_x = 0
        phy_y = 0
    else:
        # 有效数据
        no_detect_count = 0  # 重置计数器
        # 将坐标转换为整数（像素坐标）
        rc_x = int(rect_center[0])
        rc_y = int(rect_center[1])
        dist = int(distance_mm)
        phy_x = int(physical_x * 10)  # 放大10倍保持精度
        phy_y = int(physical_y * 10)

    # 16进制数据包格式：
    # 包头(1B) + 矩形中心XY(各2B) + 距离(2B) + 物理坐标XY(各2B) + 校验和(1B) + 包尾(1B)
    data = bytearray([
        HEADER,
        (rc_x >> 8) & 0xFF, rc_x & 0xFF,  # 矩形中心X
        (rc_y >> 8) & 0xFF, rc_y & 0xFF,  # 矩形中心Y
        (dist >> 8) & 0xFF, dist & 0xFF,   # 距离(mm)
        (phy_x >> 8) & 0xFF, phy_x & 0xFF, # 物理X坐标(x10)
        (phy_y >> 8) & 0xFF, phy_y & 0xFF, # 物理Y坐标(x10)
        CHECKSUM,
        FOOTER
    ])

    try:
        uart.write(data)
        if is_valid:
            print(f"[UART] 发送有效数据: {[hex(b) for b in data]}")
            print(f"矩形中心: ({rc_x},{rc_y})")
#            print(f"距离: {distance_mm:.1f}mm 物理坐标: X={physical_x:.1f}mm Y={physical_y:.1f}mm")
        else:
            print("[UART] 连续未检测到目标，发送全0数据")
        return True
    except Exception as e:
        print(f"串口发送失败: {e}")
        return Fals

#def detect_outer_rectangle(img):
#    """检测外接矩形并计算坐标(优化版)"""
#    global img_okcount

#    try:
#        if img is None:
#            print("错误: 输入图像为空")
#            return False

#        img_width = img.width()
#        img_height = img.height()
#        screen_center = (img_width // 2, img_height // 2)  # 屏幕中心坐标

#        gray = img.to_grayscale()
#        counts = gray.find_rects(threshold=THRESHOLD_VALUES["RECT_DETECT_THRESHOLD"])

#        best_rect = None
#        max_area = 0
#        min_area_threshold = img_width * img_height * 0.03  # 设置最小面积阈值为图像总面积的5%

#        for r in counts:
#            x, y, w, h = r.rect()
#            area = w * h
#            aspect_ratio = float(w) / h

#            # 添加面积过滤条件
#            if (MIN_ASPECT_RATIO < aspect_ratio < MAX_ASPECT_RATIO and
#                area > max_area and
#                area > min_area_threshold):
#                max_area = area
#                best_rect = r

#        if best_rect:
#            x1, y1 = best_rect.rect()[0], best_rect.rect()[1]
#            x2, y2 = x1 + best_rect.rect()[2], y1 + best_rect.rect()[3]
#            rect_center = ((x1 + x2) // 2, (y1 + y2) // 2)  # 矩形中心坐标

#            # 验证矩形有效性
#            border_gray = gray.get_statistics(roi=(x1, y1, best_rect.rect()[2], 5)).mean()
#            center_gray = gray.get_statistics(roi=(rect_center[0], rect_center[1], 4, 4)).mean()

#            if (border_gray < THRESHOLD_VALUES["BLACK_GRAY_THRESHOLD"] and
#                center_gray > THRESHOLD_VALUES["CENTER_GRAY_THRESHOLD"]):

#                img_okcount += 1
#                distance_mm, physical_x, physical_y = calculate_distance_and_position(
#                    best_rect.rect(), img_width, img_height)

#                # 绘制图形元素
#                img.draw_rectangle(best_rect.rect(), color=(255, 0, 0), thickness=2)
#                img.draw_circle(rect_center[0], rect_center[1], 5, color=(255, 0, 0), fill=True)
#                img.draw_line(screen_center[0], screen_center[1],
#                            rect_center[0], rect_center[1],
#                            color=(0, 255, 0), thickness=2)
#                img.draw_circle(screen_center[0], screen_center[1], 5, color=(0, 0, 255), fill=True)

#                # 显示调试信息
#                img.draw_string(10, 10, f"检测成功: {img_okcount}", color=(255,255,255), scale=2)
#                img.draw_string(10, 40, f"距离: {distance_mm:.1f}mm", color=(255,255,255), scale=1.5)
#                img.draw_string(10, 70, f"物理坐标: X={physical_x:.1f}mm Y={physical_y:.1f}mm",
#                              color=(255,255,255), scale=1.2)
#                img.draw_string(10, 100, f"宽高比: {float(best_rect.rect()[2])/best_rect.rect()[3]:.2f}",
#                              color=(255,255,255), scale=1.2)

#                # 发送串口数据
#                send_uart_data(screen_center, rect_center, distance_mm, physical_x, physical_y)
#                return True

#        img.draw_string(20, 20, "未检测到目标", color=(255,0,0), scale=3)
#        return False
#    except Exception as e:
#        print(f"检测错误: {e}")
#        return False

def detect_outer_rectangle(img):
    """检测外接矩形并计算坐标(优化版)"""
    global img_okcount, no_detect_count

    try:
        if img is None:
            print("错误: 输入图像为空")
            return False

        img_width = img.width()
        img_height = img.height()
        screen_center = (img_width // 2, img_height // 2)  # 屏幕中心坐标

        gray = img.to_grayscale()
        counts = gray.find_rects(threshold=THRESHOLD_VALUES["RECT_DETECT_THRESHOLD"])

        best_rect = None
        max_area = 0
        min_area_threshold = img_width * img_height * 0.0032  # 设置最小面积阈值为图像总面积的3%

        for r in counts:
            x, y, w, h = r.rect()
            area = w * h
            aspect_ratio = float(w) / h

            # 添加面积过滤条件
            if (MIN_ASPECT_RATIO < aspect_ratio < MAX_ASPECT_RATIO and
                area > max_area and
                area > min_area_threshold):
                max_area = area
                best_rect = r

        if best_rect:
            x1, y1 = best_rect.rect()[0], best_rect.rect()[1]
            x2, y2 = x1 + best_rect.rect()[2], y1 + best_rect.rect()[3]
            rect_center = ((x1 + x2) // 2, (y1 + y2) // 2)  # 矩形中心坐标

            # 验证矩形有效性
            border_gray = gray.get_statistics(roi=(x1, y1, best_rect.rect()[2], 5)).mean()
            center_gray = gray.get_statistics(roi=(rect_center[0], rect_center[1], 4, 4)).mean()

            if (border_gray < THRESHOLD_VALUES["BLACK_GRAY_THRESHOLD"] and
                center_gray > THRESHOLD_VALUES["CENTER_GRAY_THRESHOLD"]):

                img_okcount += 1
                distance_mm, physical_x, physical_y = calculate_distance_and_position(
                    best_rect.rect(), img_width, img_height)

                # 绘制图形元素
                img.draw_rectangle(best_rect.rect(), color=(255, 0, 0), thickness=2)
                img.draw_circle(rect_center[0], rect_center[1], 5, color=(255, 0, 0), fill=True)
                img.draw_line(screen_center[0], screen_center[1],
                            rect_center[0], rect_center[1],
                            color=(0, 255, 0), thickness=2)
                img.draw_circle(screen_center[0], screen_center[1], 5, color=(0, 0, 255), fill=True)

                # 显示调试信息
                img.draw_string(10, 10, f"检测成功: {img_okcount}", color=(255,255,255), scale=2)
                img.draw_string(10, 40, f"距离: {distance_mm:.1f}mm", color=(255,255,255), scale=1.5)
                img.draw_string(10, 70, f"物理坐标: X={physical_x:.1f}mm Y={physical_y:.1f}mm",
                              color=(255,255,255), scale=1.2)
                img.draw_string(10, 100, f"宽高比: {float(best_rect.rect()[2])/best_rect.rect()[3]:.2f}",
                              color=(255,255,255), scale=1.2)

                # 发送串口数据
                send_uart_data(screen_center, rect_center, distance_mm, physical_x, physical_y, is_valid=True)
                return True

        # 未检测到有效目标
        img.draw_string(20, 20, "未检测到目标", color=(255,0,0), scale=3)
        send_uart_data((0,0), (0,0), 0, 0, 0, is_valid=False)
        return False
    except Exception as e:
        print(f"检测错误: {e}")
        send_uart_data((0,0), (0,0), 0, 0, 0, is_valid=False)
        return False


def main_loop():
    fps = time.clock()
    while running:
        try:
            fps.tick()
            os.exitpoint()

            img = sensor.snapshot()

            if detect_outer_rectangle(img):
                img.draw_string(20, 20, "检测成功!", color=(0, 255, 0), scale=3)
            else:
                img.draw_string(20, 20, "未检测到目标", color=(255, 0, 0), scale=3)

            # 显示固定阈值信息
            img.draw_string(20, 60, f"边框阈值: {THRESHOLD_VALUES['BLACK_GRAY_THRESHOLD']}",
                          color=(255, 255, 255), scale=2)
            img.draw_string(20, 100, f"中心阈值: {THRESHOLD_VALUES['CENTER_GRAY_THRESHOLD']}",
                          color=(255, 255, 255), scale=2)
            img.draw_string(20, 140, f"检测灵敏度: {THRESHOLD_VALUES['RECT_DETECT_THRESHOLD']}",
                          color=(255, 255, 255), scale=2)

            # 显示帧率
            img.draw_string(DISPLAY_WIDTH-150, DISPLAY_HEIGHT-40,
                          f"FPS: {fps.fps():.1f}", color=(255,255,255), scale=2)

            Display.show_image(img)
            gc.collect()

        except KeyboardInterrupt:
            global running
            running = False
        except Exception as e:
            print(f"主循环错误: {e}")
            time.sleep(0.5)

def main():
    os.exitpoint(os.EXITPOINT_ENABLE)
    try:
        camera_init()
        main_loop()
    except Exception as e:
        print(f"主程序错误: {e}")
    finally:
        camera_deinit()
        print("程序结束")

if __name__ == "__main__":
    main()
